import { useState, type ReactNode } from 'react';
import { Menu, X } from 'lucide-react';
import { NAV_ITEMS, type PageKey } from './nav';

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 shadow-glow">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="10" r="5.5" fill="white" />
          <circle cx="10" cy="9" r="1.4" fill="#0b5ced" />
          <circle cx="14" cy="9" r="1.4" fill="#0b5ced" />
          <circle cx="8.6" cy="6.4" r="1.6" fill="white" />
          <circle cx="15.4" cy="6.4" r="1.6" fill="white" />
          <path d="M9.5 21v-4.5M14.5 21v-4.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <div className="leading-tight">
        <p className="font-display text-lg font-extrabold tracking-tight text-white">PANDA</p>
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-blue-400">NEXQ Marketing</p>
      </div>
    </div>
  );
}

export function AppShell({
  page,
  onNavigate,
  children,
}: {
  page: PageKey;
  onNavigate: (p: PageKey) => void;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);

  const navList = (
    <nav className="flex flex-col gap-1">
      {NAV_ITEMS.map((item) => {
        const active = item.key === page;
        return (
          <button
            key={item.key}
            onClick={() => {
              onNavigate(item.key);
              setOpen(false);
            }}
            className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all duration-200 ${
              active
                ? 'bg-blue-600/15 text-white border border-blue-500/30 shadow-glow'
                : 'text-slate-400 hover:text-white hover:bg-navy-800/80 border border-transparent'
            }`}
          >
            <span className={active ? 'text-blue-400' : ''}>{item.icon}</span>
            {item.label}
          </button>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-navy-950">
      <div className="pointer-events-none fixed inset-x-0 top-0 z-0 h-72 bg-[radial-gradient(ellipse_at_top,rgba(26,115,255,0.12),transparent_65%)]" />
      <div className="relative z-10 mx-auto flex max-w-[1500px]">
        {/* Sidebar - desktop */}
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-navy-800/70 bg-navy-900/60 px-4 py-6 backdrop-blur lg:flex">
          <div className="px-2">
            <Logo />
          </div>
          <div className="mt-8 flex-1">{navList}</div>
          <div className="rounded-xl border border-navy-700/60 bg-navy-900 p-3.5">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Powered by</p>
            <p className="mt-0.5 text-sm font-bold text-white">
              NEXQ <span className="font-medium text-slate-400">technology</span>
            </p>
            <p className="mt-1 text-[11px] leading-snug text-slate-500">Intelligent marketing. Measurable growth.</p>
          </div>
        </aside>

        {/* Mobile header */}
        <header className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b border-navy-800 bg-navy-950/90 px-4 py-3 backdrop-blur lg:hidden">
          <Logo />
          <button
            onClick={() => setOpen(!open)}
            className="rounded-lg p-2 text-slate-300 hover:bg-navy-800"
            aria-label="Toggle menu"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </header>
        {open && (
          <div className="fixed inset-0 top-[61px] z-30 overflow-y-auto bg-navy-950/98 px-4 py-4 backdrop-blur lg:hidden">
            {navList}
          </div>
        )}

        <main className="min-w-0 flex-1 px-4 pb-16 pt-20 sm:px-6 lg:px-10 lg:pt-10">{children}</main>
      </div>
    </div>
  );
}
