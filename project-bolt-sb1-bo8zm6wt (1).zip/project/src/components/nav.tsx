import type { ReactNode } from 'react';
import {
  LayoutDashboard,
  Target,
  Rocket,
  PenTool,
  Share2,
  Users,
  BarChart3,
  Sparkles,
  Settings,
} from 'lucide-react';

export type PageKey =
  | 'dashboard'
  | 'strategy'
  | 'campaigns'
  | 'content'
  | 'social'
  | 'leads'
  | 'analytics'
  | 'assistant'
  | 'settings';

export const NAV_ITEMS: { key: PageKey; label: string; icon: ReactNode }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { key: 'strategy', label: 'Marketing Strategy', icon: <Target size={18} /> },
  { key: 'campaigns', label: 'Campaign Studio', icon: <Rocket size={18} /> },
  { key: 'content', label: 'Content Creator', icon: <PenTool size={18} /> },
  { key: 'social', label: 'Social Media', icon: <Share2 size={18} /> },
  { key: 'leads', label: 'Leads', icon: <Users size={18} /> },
  { key: 'analytics', label: 'Marketing Analytics', icon: <BarChart3 size={18} /> },
  { key: 'assistant', label: 'AI Marketing Assistant', icon: <Sparkles size={18} /> },
  { key: 'settings', label: 'Settings', icon: <Settings size={18} /> },
];
