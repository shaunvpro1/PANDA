import type { ReactNode } from 'react';

export function StatCard({
  label,
  value,
  delta,
  icon,
  accent = 'blue',
}: {
  label: string;
  value: string;
  delta?: string;
  icon: ReactNode;
  accent?: 'blue' | 'green' | 'amber' | 'red';
}) {
  const accents: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400',
    green: 'bg-emerald-500/10 text-emerald-400',
    amber: 'bg-amber-500/10 text-amber-400',
    red: 'bg-red-500/10 text-red-400',
  };
  const deltaColor =
    delta?.startsWith('+') ? 'text-emerald-400' : delta?.startsWith('-') ? 'text-red-400' : 'text-slate-400';
  return (
    <div className="card card-hover p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-slate-400">{label}</p>
          <p className="mt-2 font-display text-2xl font-bold text-white">{value}</p>
          {delta && <p className={`mt-1 text-xs font-medium ${deltaColor}`}>{delta} vs last period</p>}
        </div>
        <div className={`rounded-xl p-2.5 ${accents[accent]}`}>{icon}</div>
      </div>
    </div>
  );
}

const badgeStyles: Record<string, string> = {
  draft: 'bg-slate-500/15 text-slate-300',
  active: 'bg-emerald-500/15 text-emerald-400',
  scheduled: 'bg-blue-500/15 text-blue-400',
  published: 'bg-navy-500/25 text-blue-300',
  paused: 'bg-amber-500/15 text-amber-400',
  completed: 'bg-navy-500/30 text-slate-300',
  new: 'bg-blue-500/15 text-blue-400',
  contacted: 'bg-amber-500/15 text-amber-400',
  qualified: 'bg-cyan-500/15 text-cyan-400',
  won: 'bg-emerald-500/15 text-emerald-400',
  lost: 'bg-red-500/15 text-red-400',
};

export function StatusBadge({ status }: { status: string }) {
  return <span className={`badge ${badgeStyles[status] ?? badgeStyles.draft}`}>{status}</span>;
}

export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between mb-8">
      <div>
        <h1 className="font-display text-2xl font-bold text-white tracking-tight sm:text-3xl">{title}</h1>
        <p className="mt-1.5 text-sm text-slate-400 max-w-2xl leading-relaxed">{subtitle}</p>
      </div>
      {children && <div className="flex shrink-0 items-center gap-3">{children}</div>}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  hint,
}: {
  icon: ReactNode;
  title: string;
  hint: string;
}) {
  return (
    <div className="card flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="rounded-2xl bg-navy-800 p-4 text-blue-400">{icon}</div>
      <p className="mt-4 font-semibold text-white">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-slate-400">{hint}</p>
    </div>
  );
}

export function Spinner() {
  return (
    <div className="flex items-center justify-center py-16">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-navy-600 border-t-blue-500" />
    </div>
  );
}

export function Bar({
  value,
  max,
  className = 'bg-blue-500',
}: {
  value: number;
  max: number;
  className?: string;
}) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="h-2 w-full rounded-full bg-navy-800 overflow-hidden">
      <div className={`h-full rounded-full transition-all duration-500 ${className}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function fmtMoney(n: number): string {
  return '$' + n.toLocaleString(undefined, { maximumFractionDigits: 0 });
}

export function fmtCompact(n: number): string {
  return n.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 1 });
}

export function fmtDate(d: string | null): string {
  if (!d) return '—';
  return new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}
