import { useMemo } from 'react';
import { BarChart3 } from 'lucide-react';
import { useTable } from '@/lib/useTable';
import type { Campaign, Lead, Metric } from '@/lib/types';
import { PageHeader, StatCard, Spinner, Bar, fmtCompact, fmtMoney } from '@/components/ui';

function TrendArea({ metrics }: { metrics: Metric[] }) {
  const rows = [...metrics].reverse();
  const revMax = Math.max(...rows.map((r) => r.revenue), 1);
  const spendMax = Math.max(...rows.map((r) => r.spend), 1);
  return (
    <div className="relative h-40">
      <div className="absolute inset-0 flex items-end gap-1">
        {rows.map((r) => (
          <div key={r.id} className="flex h-full flex-1 flex-col justify-end gap-px" title={`${r.day} — revenue ${fmtMoney(Number(r.revenue))}, spend ${fmtMoney(Number(r.spend))}`}>
            <div className="rounded-t-sm bg-gradient-to-t from-emerald-600/50 to-emerald-400" style={{ height: `${(r.revenue / revMax) * 60}%` }} />
            <div className="rounded-b-sm bg-gradient-to-b from-blue-600/50 to-blue-400/70" style={{ height: `${(r.spend / spendMax) * 40}%` }} />
          </div>
        ))}
      </div>
    </div>
  );
}

export function Analytics() {
  const { data: metrics, loading } = useTable<Metric>('metrics', { column: 'day', ascending: false });
  const { data: campaigns } = useTable<Campaign>('campaigns', { column: 'created_at' });
  const { data: leads } = useTable<Lead>('leads', { column: 'created_at' });

  const stats = useMemo(() => {
    const last30 = metrics.slice(0, 30);
    const prev30 = metrics.slice(30, 60);
    const s = (rows: Metric[], key: keyof Metric) => rows.reduce((a, r) => a + Number(r[key] ?? 0), 0);
    const spend = s(last30, 'spend');
    const revenue = s(last30, 'revenue');
    const clicks = s(last30, 'clicks');
    const impressions = s(last30, 'impressions');
    const conversions = s(last30, 'conversions');
    const prevRevenue = s(prev30, 'revenue');
    const prevSpend = s(prev30, 'spend');
    return {
      last30,
      spend,
      revenue,
      clicks,
      impressions,
      conversions,
      roas: spend ? revenue / spend : 0,
      cpl: conversions ? spend / conversions : 0,
      ctr: impressions ? (clicks / impressions) * 100 : 0,
      romi: prevSpend ? ((revenue - prevRevenue) / prevRevenue) * 100 : 0,
      revenueDelta: prevRevenue ? `${revenue >= prevRevenue ? '+' : '-'}${Math.round(Math.abs(((revenue - prevRevenue) / prevRevenue) * 100))}%` : undefined,
      spendDelta: prevSpend ? `${spend >= prevSpend ? '+' : '-'}${Math.round(Math.abs(((spend - prevSpend) / prevSpend) * 100))}%` : undefined,
    };
  }, [metrics]);

  const leadSourceCounts = useMemo(() => {
    const map = new Map<string, number>();
    leads.forEach((l) => map.set(l.source, (map.get(l.source) ?? 0) + 1));
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [leads]);
  const maxSource = Math.max(...leadSourceCounts.map(([, c]) => c), 1);

  if (loading) return <Spinner />;

  const recommendations: string[] = [];
  if (stats.roas >= 3) recommendations.push('Your return on marketing spend is healthy (above 3x). Consider gradually increasing budget on your best-performing channel.');
  else if (stats.roas >= 1.5) recommendations.push('ROAS is workable but has room to improve. Tighten your audience targeting and test sharper offers before scaling spend.');
  else recommendations.push('Return on spend is low. Pause the weakest campaign, revisit your offer and audience, and concentrate budget on the single best channel.');
  if (stats.ctr < 1) recommendations.push('Click-through rate is under 1%. Your creative or headline likely needs a stronger hook — test bolder copy in the Content Creator.');
  if (campaigns.filter((c) => c.status === 'active').length === 0) recommendations.push('No campaigns are currently active. Launch one in Campaign Studio so new data keeps flowing into these dashboards.');
  if (leads.length === 0) recommendations.push('No leads captured yet. Add lead capture to your website and log every enquiry in the Leads workspace to measure conversion.');

  return (
    <div>
      <PageHeader
        title="Marketing Analytics"
        subtitle="Performance, expenditure and return on marketing investment — measured, tracked and translated into next steps."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Spend (30d)" value={fmtMoney(stats.spend)} delta={stats.spendDelta} icon={<BarChart3 size={20} />} accent="blue" />
        <StatCard label="Revenue (30d)" value={fmtMoney(stats.revenue)} delta={stats.revenueDelta} icon={<BarChart3 size={20} />} accent="green" />
        <StatCard label="ROAS" value={`${stats.roas.toFixed(1)}x`} icon={<BarChart3 size={20} />} accent={stats.roas >= 3 ? 'green' : 'amber'} />
        <StatCard label="Cost per conversion" value={fmtMoney(stats.cpl)} icon={<BarChart3 size={20} />} accent="amber" />
      </div>

      <div className="mt-6 card p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="section-title">Revenue vs spend — last 30 days</h2>
            <p className="mt-0.5 text-xs text-slate-500">Green: attributed revenue · Blue: marketing spend</p>
          </div>
          <div className="flex gap-4 text-xs">
            <span className="inline-flex items-center gap-1.5 text-slate-400"><span className="h-2.5 w-2.5 rounded-sm bg-emerald-400" /> Revenue {fmtMoney(stats.revenue)}</span>
            <span className="inline-flex items-center gap-1.5 text-slate-400"><span className="h-2.5 w-2.5 rounded-sm bg-blue-400" /> Spend {fmtMoney(stats.spend)}</span>
          </div>
        </div>
        <TrendArea metrics={stats.last30} />
        <div className="mt-4 grid grid-cols-2 gap-4 border-t border-navy-800 pt-4 sm:grid-cols-4">
          <div>
            <p className="text-xs text-slate-500">Impressions</p>
            <p className="mt-0.5 font-semibold text-white">{fmtCompact(stats.impressions)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Clicks</p>
            <p className="mt-0.5 font-semibold text-white">{fmtCompact(stats.clicks)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">CTR</p>
            <p className="mt-0.5 font-semibold text-white">{stats.ctr.toFixed(2)}%</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Conversions</p>
            <p className="mt-0.5 font-semibold text-white">{fmtCompact(stats.conversions)}</p>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className="card p-6">
          <h2 className="section-title mb-4">Leads by source</h2>
          {leadSourceCounts.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">No leads recorded yet.</p>
          ) : (
            <div className="space-y-3.5">
              {leadSourceCounts.map(([source, count]) => (
                <div key={source} className="flex items-center gap-4">
                  <span className="w-20 shrink-0 text-xs font-medium capitalize text-slate-400">{source}</span>
                  <Bar value={count} max={maxSource} className="bg-gradient-to-r from-blue-600 to-blue-400" />
                  <span className="w-7 shrink-0 text-right text-sm font-semibold text-white">{count}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-6">
          <h2 className="section-title mb-4">PANDA recommendations</h2>
          <div className="space-y-3">
            {recommendations.map((rec, i) => (
              <div key={i} className="flex gap-3 rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-[11px] font-bold text-white">{i + 1}</span>
                <p className="text-sm leading-relaxed text-slate-300">{rec}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 card p-6">
        <h2 className="section-title mb-4">Campaign budget overview</h2>
        {campaigns.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">No campaigns yet — budgets will be tracked here once you create campaigns.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-navy-800 text-xs uppercase tracking-wider text-slate-500">
                  <th className="pb-3 pr-4 font-medium">Campaign</th>
                  <th className="pb-3 pr-4 font-medium">Objective</th>
                  <th className="pb-3 pr-4 font-medium">Budget</th>
                  <th className="pb-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {campaigns.map((c) => (
                  <tr key={c.id} className="border-b border-navy-800/50 last:border-0">
                    <td className="py-3 pr-4 font-medium text-white">{c.name}</td>
                    <td className="py-3 pr-4 capitalize text-slate-400">{c.objective}</td>
                    <td className="py-3 pr-4 text-slate-300">{fmtMoney(Number(c.budget))}</td>
                    <td className="py-3 capitalize text-slate-400">{c.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
