import { useState } from 'react';
import { Plus, Users, Trash2, Mail, Building2, DollarSign, Search } from 'lucide-react';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import type { Lead, LeadStatus } from '@/lib/types';
import { PageHeader, Spinner, StatusBadge, EmptyState, Bar, fmtMoney } from '@/components/ui';

const STATUSES: LeadStatus[] = ['new', 'contacted', 'qualified', 'won', 'lost'];
const SOURCES = ['manual', 'website', 'referral', 'social', 'campaign', 'email'];

const emptyForm = {
  name: '',
  email: '',
  company: '',
  source: 'website',
  value: '',
  notes: '',
};

export function Leads() {
  const { data: leads, loading, refetch } = useTable<Lead>('leads', { column: 'created_at' });
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | LeadStatus>('all');

  const set = (patch: Partial<typeof emptyForm>) => setForm((f) => ({ ...f, ...patch }));

  const add = async () => {
    if (!form.name.trim()) {
      setError('The lead needs at least a name.');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: err } = await supabase.from('leads').insert({
      name: form.name.trim(),
      email: form.email.trim(),
      company: form.company.trim(),
      source: form.source,
      value: Number(form.value) || 0,
      notes: form.notes,
      status: 'new',
    });
    setSaving(false);
    if (err) {
      setError(err.message);
      return;
    }
    setForm(emptyForm);
    setShowForm(false);
    refetch();
  };

  const setStatus = async (id: string, status: LeadStatus) => {
    await supabase.from('leads').update({ status }).eq('id', id);
    refetch();
  };

  const remove = async (id: string) => {
    await supabase.from('leads').delete().eq('id', id);
    refetch();
  };

  if (loading) return <Spinner />;

  const filtered = leads.filter((l) => {
    const matchesQuery =
      !query ||
      [l.name, l.email, l.company].some((f) => f.toLowerCase().includes(query.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || l.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  const byStatus = STATUSES.map((s) => ({ status: s, count: leads.filter((l) => l.status === s).length }));
  const maxCount = Math.max(...byStatus.map((b) => b.count), 1);
  const won = leads.filter((l) => l.status === 'won');
  const pipeline = leads.filter((l) => !['won', 'lost'].includes(l.status)).reduce((a, l) => a + Number(l.value), 0);
  const wonValue = won.reduce((a, l) => a + Number(l.value), 0);
  const convRate = leads.length ? Math.round((won.length / leads.length) * 100) : 0;

  return (
    <div>
      <PageHeader
        title="Leads"
        subtitle="Capture, track and convert prospects — every lead with its source, status and value, so nothing slips through."
      >
        <button onClick={() => setShowForm(!showForm)} className="btn-primary">
          <Plus size={16} /> Add lead
        </button>
      </PageHeader>

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Total leads</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{leads.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Open pipeline</p>
          <p className="mt-1 font-display text-2xl font-bold text-blue-400">{fmtMoney(pipeline)}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Won value</p>
          <p className="mt-1 font-display text-2xl font-bold text-emerald-400">{fmtMoney(wonValue)}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Win rate</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{convRate}%</p>
        </div>
      </div>

      <div className="card mb-6 p-6">
        <h2 className="section-title mb-4">Pipeline by stage</h2>
        <div className="space-y-3">
          {byStatus.map((b) => (
            <div key={b.status} className="flex items-center gap-4">
              <span className="w-24 shrink-0 text-xs font-medium capitalize text-slate-400">{b.status}</span>
              <Bar
                value={b.count}
                max={maxCount}
                className={
                  b.status === 'won' ? 'bg-emerald-500' : b.status === 'lost' ? 'bg-red-500' : 'bg-blue-500'
                }
              />
              <span className="w-8 shrink-0 text-right text-sm font-semibold text-white">{b.count}</span>
            </div>
          ))}
        </div>
      </div>

      {showForm && (
        <div className="card mb-6 border-blue-500/30 p-6">
          <h2 className="section-title mb-5">Add lead</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Name *</label>
              <input className="input" value={form.name} onChange={(e) => set({ name: e.target.value })} />
            </div>
            <div>
              <label className="label">Email</label>
              <input className="input" type="email" value={form.email} onChange={(e) => set({ email: e.target.value })} />
            </div>
            <div>
              <label className="label">Company</label>
              <input className="input" value={form.company} onChange={(e) => set({ company: e.target.value })} />
            </div>
            <div>
              <label className="label">Source</label>
              <select className="input capitalize" value={form.source} onChange={(e) => set({ source: e.target.value })}>
                {SOURCES.map((s) => (
                  <option key={s} value={s} className="bg-navy-900">{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Estimated value ($)</label>
              <input className="input" type="number" value={form.value} onChange={(e) => set({ value: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Notes</label>
              <textarea className="input min-h-[70px]" value={form.notes} onChange={(e) => set({ notes: e.target.value })} />
            </div>
          </div>
          {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
          <div className="mt-5 flex gap-3">
            <button onClick={add} disabled={saving} className="btn-primary">{saving ? 'Saving…' : 'Save lead'}</button>
            <button onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input className="input pl-10" placeholder="Search name, email or company…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <div className="flex flex-wrap gap-2">
          {(['all', ...STATUSES] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`rounded-full px-3.5 py-1.5 text-xs font-medium capitalize transition-colors ${
                statusFilter === s ? 'bg-blue-600 text-white' : 'bg-navy-800 text-slate-400 border border-navy-700 hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Users size={24} />}
          title={leads.length === 0 ? 'No leads yet' : 'No matches'}
          hint={leads.length === 0 ? 'Add your first lead above. As your campaigns run, log every enquiry here with its source so you can measure what actually generates customers.' : 'Try a different search or filter.'}
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((l) => (
            <div key={l.id} className="card card-hover flex flex-col gap-4 p-5 lg:flex-row lg:items-center lg:justify-between">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="font-semibold text-white">{l.name}</h3>
                  <StatusBadge status={l.status} />
                  <span className="badge bg-navy-500/25 text-blue-300 capitalize">{l.source}</span>
                </div>
                <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-xs text-slate-500">
                  {l.email && (
                    <span className="inline-flex items-center gap-1.5"><Mail size={13} /> {l.email}</span>
                  )}
                  {l.company && (
                    <span className="inline-flex items-center gap-1.5"><Building2 size={13} /> {l.company}</span>
                  )}
                  <span className="inline-flex items-center gap-1.5"><DollarSign size={13} /> {fmtMoney(Number(l.value))}</span>
                </div>
                {l.notes && <p className="mt-2 line-clamp-2 text-sm text-slate-400">{l.notes}</p>}
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <select
                  className="input w-auto py-1.5 text-xs capitalize"
                  value={l.status}
                  onChange={(e) => setStatus(l.id, e.target.value as LeadStatus)}
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s} className="bg-navy-900">{s}</option>
                  ))}
                </select>
                <button onClick={() => remove(l.id)} className="btn-ghost text-red-400 hover:text-red-300">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
