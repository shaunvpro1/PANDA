import { useState } from 'react';
import { CalendarDays, Share2, Trash2, Plus, Send, FileEdit, BarChart3 } from 'lucide-react';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import type { SocialPost } from '@/lib/types';
import { PageHeader, Spinner, StatusBadge, EmptyState, Bar, fmtCompact, fmtDate } from '@/components/ui';

const PLATFORMS = ['Instagram', 'Facebook', 'LinkedIn', 'X (Twitter)', 'TikTok'];
const PLATFORM_COLORS: Record<string, string> = {
  Instagram: 'bg-pink-500/15 text-pink-300',
  Facebook: 'bg-blue-500/15 text-blue-300',
  LinkedIn: 'bg-sky-500/15 text-sky-300',
  'X (Twitter)': 'bg-slate-500/20 text-slate-300',
  TikTok: 'bg-cyan-500/15 text-cyan-300',
};

export function SocialMedia() {
  const { data: posts, loading, refetch } = useTable<SocialPost>('social_posts', { column: 'scheduled_at', ascending: true });
  const [platform, setPlatform] = useState('Instagram');
  const [content, setContent] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState('all');

  const add = async () => {
    if (!content.trim()) {
      setError('Write the post content first.');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: err } = await supabase.from('social_posts').insert({
      platform,
      content: content.trim(),
      scheduled_at: scheduledAt || null,
      status: scheduledAt ? 'scheduled' : 'draft',
    });
    setSaving(false);
    if (err) {
      setError(err.message);
      return;
    }
    setContent('');
    setScheduledAt('');
    setShowForm(false);
    refetch();
  };

  const publish = async (id: string) => {
    await supabase.from('social_posts').update({ status: 'published' }).eq('id', id);
    refetch();
  };

  const remove = async (id: string) => {
    await supabase.from('social_posts').delete().eq('id', id);
    refetch();
  };

  if (loading) return <Spinner />;

  const published = posts.filter((p) => p.status === 'published');
  const scheduled = posts.filter((p) => p.status === 'scheduled');
  const maxImpr = Math.max(...published.map((p) => p.impressions), 1);
  const totalEngagement = published.reduce((a, p) => a + p.likes + p.comments, 0);
  const avgEng = published.length ? Math.round(totalEngagement / published.length) : 0;

  const visible = filter === 'all' ? posts : posts.filter((p) => p.status === filter);
  const upcoming = scheduled
    .filter((p) => p.scheduled_at)
    .slice(0, 5);

  return (
    <div>
      <PageHeader
        title="Social Media"
        subtitle="Your content calendar and posting pipeline — draft, schedule and track performance across every platform."
      >
        <button onClick={() => setShowForm(!showForm)} className="btn-primary">
          <Plus size={16} /> New post
        </button>
      </PageHeader>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Published</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{published.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Scheduled</p>
          <p className="mt-1 font-display text-2xl font-bold text-blue-400">{scheduled.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Total impressions</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{fmtCompact(published.reduce((a, p) => a + p.impressions, 0))}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Avg engagement / post</p>
          <p className="mt-1 font-display text-2xl font-bold text-emerald-400">{fmtCompact(avgEng)}</p>
        </div>
      </div>

      {showForm && (
        <div className="card mb-6 border-blue-500/30 p-6">
          <h2 className="section-title mb-5">New post</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Platform</label>
              <select className="input" value={platform} onChange={(e) => setPlatform(e.target.value)}>
                {PLATFORMS.map((p) => (
                  <option key={p} value={p} className="bg-navy-900">{p}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Schedule for (optional)</label>
              <input className="input" type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Post content</label>
              <textarea className="input min-h-[110px]" placeholder="Write or paste your post here…" value={content} onChange={(e) => setContent(e.target.value)} />
            </div>
          </div>
          {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
          <div className="mt-5 flex gap-3">
            <button onClick={add} disabled={saving} className="btn-primary">
              {saving ? 'Saving…' : 'Add to calendar'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      {upcoming.length > 0 && (
        <div className="card mb-6 p-6">
          <div className="mb-4 flex items-center gap-2">
            <CalendarDays size={17} className="text-blue-400" />
            <h2 className="section-title">Upcoming schedule</h2>
          </div>
          <div className="space-y-3">
            {upcoming.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-4 rounded-xl bg-navy-800/50 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm text-slate-300">{p.content}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{new Date(p.scheduled_at!).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                </div>
                <span className={`badge shrink-0 ${PLATFORM_COLORS[p.platform] ?? PLATFORM_COLORS.Facebook}`}>{p.platform}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mb-4 flex flex-wrap gap-2">
        {['all', 'draft', 'scheduled', 'published'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3.5 py-1.5 text-xs font-medium capitalize transition-colors ${
              filter === f ? 'bg-blue-600 text-white' : 'bg-navy-800 text-slate-400 border border-navy-700 hover:text-white'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <EmptyState
          icon={<Share2 size={24} />}
          title="Nothing here yet"
          hint="Add posts to your calendar, or generate polished content in the Content Creator and paste it in. Mark posts as published to start tracking their performance."
        />
      ) : (
        <div className="space-y-4">
          {visible.map((p) => (
            <div key={p.id} className="card card-hover p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className={`badge ${PLATFORM_COLORS[p.platform] ?? PLATFORM_COLORS.Facebook}`}>{p.platform}</span>
                    <StatusBadge status={p.status} />
                    {p.scheduled_at && (
                      <span className="text-xs text-slate-500">{new Date(p.scheduled_at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                    )}
                  </div>
                  <p className="mt-2.5 whitespace-pre-wrap text-sm leading-relaxed text-slate-300">{p.content}</p>
                  {p.status === 'published' && (
                    <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                      <div>
                        <p className="text-[11px] uppercase tracking-wide text-slate-500">Impressions</p>
                        <p className="text-sm font-semibold text-white">{fmtCompact(p.impressions)}</p>
                        <Bar value={p.impressions} max={maxImpr} className="bg-blue-500" />
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wide text-slate-500">Likes</p>
                        <p className="text-sm font-semibold text-white">{fmtCompact(p.likes)}</p>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wide text-slate-500">Comments</p>
                        <p className="text-sm font-semibold text-white">{fmtCompact(p.comments)}</p>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wide text-slate-500">Clicks</p>
                        <p className="text-sm font-semibold text-white">{fmtCompact(p.clicks)}</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  {p.status !== 'published' && (
                    <button onClick={() => publish(p.id)} className="btn-ghost text-emerald-400 hover:text-emerald-300" title="Mark as published">
                      {p.status === 'scheduled' ? <Send size={15} /> : <FileEdit size={15} />} Publish
                    </button>
                  )}
                  {p.status === 'published' && <BarChart3 size={15} className="text-slate-600" />}
                  <button onClick={() => remove(p.id)} className="btn-ghost text-red-400 hover:text-red-300">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
