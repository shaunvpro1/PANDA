import { useEffect, useMemo, useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  MousePointerClick,
  Target,
  Sparkles,
  ArrowRight,
  Megaphone,
  Users,
  CalendarDays,
} from 'lucide-react';
import { useProfile } from '@/lib/useProfile';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import type { Campaign, ContentItem, Lead, Metric, SocialPost, Strategy } from '@/lib/types';
import { PageHeader, StatCard, Spinner, StatusBadge, Bar, fmtCompact, fmtMoney, EmptyState } from '@/components/ui';
import type { PageKey } from '@/components/nav';

function lastDays(metrics: Metric[], days: number): Metric[] {
  return metrics.slice(0, days);
}

function sum(rows: Metric[], key: keyof Metric): number {
  return rows.reduce((a, r) => a + Number(r[key] ?? 0), 0);
}

function MiniChart({ metrics }: { metrics: Metric[] }) {
  const rows = [...metrics].reverse();
  const max = Math.max(...rows.map((r) => r.revenue), 1);
  return (
    <div className="flex h-28 items-end gap-1">
      {rows.map((r) => (
        <div
          key={r.id}
          className="flex-1 rounded-t bg-gradient-to-t from-blue-600/40 to-blue-400 transition-all duration-300 hover:to-blue-300"
          style={{ height: `${Math.max(4, (r.revenue / max) * 100)}%` }}
          title={`Revenue ${fmtMoney(Number(r.revenue))}`}
        />
      ))}
    </div>
  );
}

export function Dashboard({ onNavigate }: { onNavigate: (p: PageKey) => void }) {
  const { profile, loading: profileLoading } = useProfile();
  const { data: metrics, loading: metricsLoading } = useTable<Metric>('metrics', { column: 'day', ascending: false });
  const { data: campaigns, loading: campaignsLoading } = useTable<Campaign>('campaigns', { column: 'created_at' });
  const { data: leads } = useTable<Lead>('leads', { column: 'created_at' });
  const { data: content } = useTable<ContentItem>('content_items', { column: 'created_at' });
  const { data: social } = useTable<SocialPost>('social_posts', { column: 'created_at' });
  const { data: strategies } = useTable<Strategy>('strategies', { column: 'created_at' });
  const [aiTip, setAiTip] = useState<string>('');

  useEffect(() => {
    supabase
      .from('assistant_messages')
      .select('body')
      .eq('role', 'assistant')
      .order('created_at', { ascending: false })
      .limit(1)
      .then(({ data }) => setAiTip(data?.[0]?.body ?? ''));
  }, []);

  const last30 = useMemo(() => lastDays(metrics, 30), [metrics]);
  const prev30 = useMemo(() => lastDays(metrics.slice(30), 30), [metrics]);

  const spend = sum(last30, 'spend');
  const revenue = sum(last30, 'revenue');
  const clicks = sum(last30, 'clicks');
  const impressions = sum(last30, 'impressions');
  const conversions = sum(last30, 'conversions');
  const prevSpend = sum(prev30, 'spend');
  const prevRevenue = sum(prev30, 'revenue');
  const prevClicks = sum(prev30, 'clicks');
  const prevImpressions = sum(prev30, 'impressions');

  const pct = (cur: number, prev: number) =>
    prev === 0 ? undefined : `${cur >= prev ? '+' : '-'}${Math.round(Math.abs(((cur - prev) / prev) * 100))}%`;

  const roas = spend > 0 ? revenue / spend : 0;
  const ctr = impressions > 0 ? (clicks / impressions) * 100 : 0;

  if (profileLoading || metricsLoading || campaignsLoading) return <Spinner />;

  const activeCampaigns = campaigns.filter((c) => c.status === 'active');
  const pipelineValue = leads.filter((l) => !['won', 'lost'].includes(l.status)).reduce((a, l) => a + Number(l.value), 0);
  const scheduledPosts = social.filter((p) => p.status === 'scheduled');

  return (
    <div>
      <PageHeader
        title={`Welcome back${profile && profile.company_name !== 'My Business' ? `, ${profile.company_name}` : ''}`}
        subtitle="Your marketing command centre — performance at a glance, with everything you need one click away."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Spend (30d)" value={fmtMoney(spend)} delta={pct(spend, prevSpend)} icon={<DollarSign size={20} />} accent="blue" />
        <StatCard label="Revenue (30d)" value={fmtMoney(revenue)} delta={pct(revenue, prevRevenue)} icon={<TrendingUp size={20} />} accent="green" />
        <StatCard label="Clicks (30d)" value={fmtCompact(clicks)} delta={pct(clicks, prevClicks)} icon={<MousePointerClick size={20} />} accent="blue" />
        <StatCard label="ROAS (30d)" value={`${roas.toFixed(1)}x`} delta={roas >= 3 ? 'Healthy' : roas >= 1.5 ? 'Watch' : 'Needs work'} icon={<Target size={20} />} accent={roas >= 3 ? 'green' : roas >= 1.5 ? 'amber' : 'red'} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="card p-6 xl:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="section-title">Revenue — last 30 days</h2>
              <p className="mt-0.5 text-xs text-slate-500">Daily attributed revenue from marketing activity</p>
            </div>
            <button onClick={() => onNavigate('analytics')} className="btn-ghost text-xs">
              Full analytics <ArrowRight size={14} />
            </button>
          </div>
          <MiniChart metrics={last30} />
          <div className="mt-4 grid grid-cols-3 gap-4 border-t border-navy-800 pt-4">
            <div>
              <p className="text-xs text-slate-500">Impressions</p>
              <p className="mt-0.5 font-semibold text-white">{fmtCompact(impressions)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">CTR</p>
              <p className="mt-0.5 font-semibold text-white">{ctr.toFixed(2)}%</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Conversions</p>
              <p className="mt-0.5 font-semibold text-white">{fmtCompact(conversions)}</p>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="section-title">Pipeline snapshot</h2>
          <div className="mt-5 space-y-5">
            <div>
              <div className="mb-1.5 flex justify-between text-sm">
                <span className="text-slate-400">Open pipeline value</span>
                <span className="font-semibold text-white">{fmtMoney(pipelineValue)}</span>
              </div>
              <Bar value={pipelineValue} max={Math.max(pipelineValue, revenue)} className="bg-gradient-to-r from-blue-600 to-blue-400" />
            </div>
            <div className="flex items-center justify-between rounded-xl bg-navy-800/60 px-4 py-3">
              <div className="flex items-center gap-3">
                <Megaphone size={18} className="text-blue-400" />
                <span className="text-sm text-slate-300">Active campaigns</span>
              </div>
              <span className="font-display font-bold text-white">{activeCampaigns.length}</span>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-navy-800/60 px-4 py-3">
              <div className="flex items-center gap-3">
                <Users size={18} className="text-emerald-400" />
                <span className="text-sm text-slate-300">Total leads</span>
              </div>
              <span className="font-display font-bold text-white">{leads.length}</span>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-navy-800/60 px-4 py-3">
              <div className="flex items-center gap-3">
                <CalendarDays size={18} className="text-amber-400" />
                <span className="text-sm text-slate-300">Scheduled posts</span>
              </div>
              <span className="font-display font-bold text-white">{scheduledPosts.length}</span>
            </div>
            <button onClick={() => onNavigate('leads')} className="btn-secondary w-full">
              Open Leads workspace <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className="card p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="section-title">Recent campaigns</h2>
            <button onClick={() => onNavigate('campaigns')} className="btn-ghost text-xs">
              Campaign Studio <ArrowRight size={14} />
            </button>
          </div>
          {campaigns.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-500">No campaigns yet — create your first in Campaign Studio.</p>
          ) : (
            <div className="space-y-3">
              {campaigns.slice(0, 4).map((c) => (
                <div key={c.id} className="flex items-center justify-between rounded-xl bg-navy-800/50 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-white">{c.name}</p>
                    <p className="text-xs capitalize text-slate-500">{c.objective} · {fmtMoney(Number(c.budget))}</p>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-blue-400" />
              <h2 className="section-title">Latest from your AI assistant</h2>
            </div>
            <button onClick={() => onNavigate('assistant')} className="btn-ghost text-xs">
              Ask PANDA <ArrowRight size={14} />
            </button>
          </div>
          <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-300">
              {aiTip || 'Ask your AI Marketing Assistant anything — budgets, content ideas, lead generation, or how to interpret your results. It knows your business profile.'}
            </p>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 text-center">
            <div className="rounded-xl bg-navy-800/60 px-3 py-3">
              <p className="font-display text-xl font-bold text-white">{strategies.length}</p>
              <p className="text-xs text-slate-500">Strategies saved</p>
            </div>
            <div className="rounded-xl bg-navy-800/60 px-3 py-3">
              <p className="font-display text-xl font-bold text-white">{content.length}</p>
              <p className="text-xs text-slate-500">Content items</p>
            </div>
          </div>
        </div>
      </div>

      {!profileLoading && profile && !profile.industry && (
        <div className="mt-6">
          <EmptyState
            icon={<Sparkles size={24} />}
            title="Complete your business profile"
            hint="The AI assistant personalises every strategy, post and recommendation using your profile. Add your industry, audience and brand voice in Settings."
          />
          <button onClick={() => onNavigate('settings')} className="btn-primary mt-4 w-full sm:w-auto">
            Set up my business profile
          </button>
        </div>
      )}
    </div>
  );
}
