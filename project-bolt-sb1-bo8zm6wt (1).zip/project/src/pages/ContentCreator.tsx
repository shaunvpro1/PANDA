import { useEffect, useRef, useState } from 'react';
import {
  PenTool,
  Sparkles,
  Copy,
  Check,
  Trash2,
  Save,
  ArrowUp,
  Loader2,
  Wand2,
  X,
} from 'lucide-react';
import { useProfile } from '@/lib/useProfile';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import { interpretBrief, generateContent, refineContent } from '@/lib/engine';
import type { ContentItem } from '@/lib/types';
import { PageHeader, Spinner, EmptyState, fmtDate } from '@/components/ui';

const QUICK_REFINEMENTS = [
  'Make it shorter',
  'Expand this',
  'Make it friendlier',
  'More professional',
  'Add a stronger call to action',
  'Give me headline options',
];

interface Interpretation {
  typeLabel: string;
  platform: string;
  tone: string;
  audience: string;
}

export function ContentCreator() {
  const { profile, loading: profileLoading } = useProfile();
  const { data: items, loading, refetch } = useTable<ContentItem>('content_items', { column: 'created_at' });

  const [prompt, setPrompt] = useState('');
  const [generated, setGenerated] = useState<{ title: string; body: string } | null>(null);
  const [interpretation, setInterpretation] = useState<Interpretation | null>(null);
  const [history, setHistory] = useState<{ role: 'user' | 'assistant'; text: string }[]>([]);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (history.length > 0) resultRef.current?.scrollTo({ top: resultRef.current.scrollHeight, behavior: 'smooth' });
  }, [history.length, busy]);

  const run = (text: string, isRefinement: boolean) => {
    const brief = text.trim();
    if (!brief || busy) return;
    setBusy(true);
    setSavedId(null);
    setCopied(false);
    setPrompt('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    try {
      if (isRefinement && generated) {
        const refined = refineContent(profile, { instruction: brief, title: generated.title, body: generated.body });
        setGenerated(refined);
        setHistory((h) => [
          ...h,
          { role: 'user', text: brief },
          { role: 'assistant', text: `Refined "${generated.title}" — ${brief.replace(/\.$/, '').toLowerCase()}.` },
        ]);
      } else {
        const b = interpretBrief(profile, brief);
        const result = generateContent(profile, {
          type: b.type,
          topic: b.topic,
          platform: b.platform || undefined,
          tone: b.tone,
          keywords: b.keywords.join(', '),
          audience: b.audience || undefined,
        });
        setGenerated(result);
        setInterpretation({
          typeLabel: b.typeLabel,
          platform: b.platform,
          tone: b.tone,
          audience: b.audience,
        });
        setHistory((h) => [
          ...h,
          { role: 'user', text: brief },
          { role: 'assistant', text: `Wrote ${b.typeLabel.toLowerCase()}${b.platform ? ` for ${b.platform}` : ''} in a ${b.tone.toLowerCase()} tone.` },
        ]);
      }
    } finally {
      setBusy(false);
    }
  };

  const saveGenerated = async () => {
    if (!generated || !interpretation) return;
    const { data, error } = await supabase
      .from('content_items')
      .insert({
        title: generated.title,
        content_type: interpretation.typeLabel === 'Email' ? 'email' : interpretation.typeLabel === 'Ad copy' ? 'ad_copy' : interpretation.typeLabel === 'Website copy' ? 'website' : interpretation.typeLabel === 'Product description' ? 'product_description' : interpretation.typeLabel === 'Campaign concept' ? 'campaign_concept' : 'social_post',
        platform: interpretation.platform,
        body: generated.body,
      })
      .select('id')
      .single();
    if (!error && data) {
      setSavedId(data.id);
      refetch();
    }
  };

  const copyToClipboard = async () => {
    if (!generated) return;
    try {
      await navigator.clipboard.writeText(generated.body);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const remove = async (id: string) => {
    await supabase.from('content_items').delete().eq('id', id);
    refetch();
  };

  if (loading || profileLoading) return <Spinner />;

  return (
    <div>
      <PageHeader
        title="Content Creator"
        subtitle="Brief PANDA in one line or a full creative brief — it decides the format, audience and tone, then writes polished, ready-to-use content."
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-5">
        {/* Prompt workspace */}
        <div className="xl:col-span-2">
          <div className="card p-5">
            <div className="mb-3 flex items-center gap-2">
              <Wand2 size={16} className="text-blue-400" />
              <h2 className="text-sm font-semibold text-white">Your brief</h2>
              {interpretation && (
                <button
                  onClick={() => {
                    setGenerated(null);
                    setInterpretation(null);
                    setHistory([]);
                    setSavedId(null);
                  }}
                  className="ml-auto btn-ghost text-[11px] text-slate-500 hover:text-white"
                >
                  <X size={12} /> Clear
                </button>
              )}
            </div>
            <textarea
              ref={textareaRef}
              rows={4}
              className="input min-h-[110px] resize-y"
              placeholder="e.g. Write an Instagram post about our spring sale for existing customers, keep it friendly — or paste a full brief with all the details…"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  run(prompt, generated !== null);
                }
              }}
              disabled={busy}
            />
            <button
              onClick={() => run(prompt, generated !== null)}
              disabled={!prompt.trim() || busy}
              className="btn-primary mt-3 w-full"
            >
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
              {busy ? 'Writing…' : generated ? 'Refine content' : 'Generate content'}
            </button>
            <p className="mt-2 text-center text-[11px] text-slate-600">
              {generated ? 'Follow up to refine, rewrite, expand or shorten — PANDA adapts it' : 'Any request works: a topic, a detailed brief, tone, platform, audience'}
            </p>

            {generated && (
              <div className="mt-5 border-t border-navy-800 pt-4">
                <p className="mb-2.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">Quick refinements</p>
                <div className="flex flex-wrap gap-2">
                  {QUICK_REFINEMENTS.map((r) => (
                    <button
                      key={r}
                      onClick={() => run(r, true)}
                      disabled={busy}
                      className="rounded-full border border-navy-700 bg-navy-800 px-3 py-1.5 text-[11px] font-medium text-slate-300 transition-colors hover:border-blue-500/50 hover:text-white disabled:opacity-50"
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {interpretation && generated && (
            <div className="card mt-4 p-5">
              <p className="mb-3 text-[11px] font-semibold uppercase tracking-wider text-slate-500">How PANDA read your brief</p>
              <div className="flex flex-wrap gap-2">
                <span className="rounded-full bg-blue-500/15 px-3 py-1.5 text-[11px] font-medium text-blue-300">{interpretation.typeLabel}</span>
                {interpretation.platform && (
                  <span className="rounded-full bg-pink-500/15 px-3 py-1.5 text-[11px] font-medium text-pink-300">{interpretation.platform}</span>
                )}
                <span className="rounded-full bg-emerald-500/15 px-3 py-1.5 text-[11px] font-medium text-emerald-300">{interpretation.tone} tone</span>
                {interpretation.audience && (
                  <span className="rounded-full bg-amber-500/15 px-3 py-1.5 text-[11px] font-medium text-amber-300">For {interpretation.audience}</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Result */}
        <div className="xl:col-span-3" ref={resultRef}>
          {generated ? (
            <div className="card border-blue-500/30 p-6">
              <div className="flex items-start justify-between gap-3">
                <h2 className="section-title">{generated.title}</h2>
                {savedId && <span className="badge shrink-0 bg-emerald-500/15 text-emerald-400">Saved</span>}
              </div>
              <pre className="mt-4 max-h-[440px] overflow-y-auto whitespace-pre-wrap rounded-xl bg-navy-950/80 p-4 font-sans text-sm leading-relaxed text-slate-300">{generated.body}</pre>
              <div className="mt-4 flex flex-wrap gap-3">
                <button onClick={copyToClipboard} className="btn-secondary">
                  {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />} {copied ? 'Copied' : 'Copy'}
                </button>
                {!savedId && (
                  <button onClick={saveGenerated} className="btn-primary">
                    <Save size={15} /> Save to library
                  </button>
                )}
              </div>
            </div>
          ) : (
            <EmptyState
              icon={<PenTool size={24} />}
              title="One prompt. Any content."
              hint="Describe what you need — 'write a LinkedIn post announcing our new consultant', 'draft an email to win back inactive customers', 'create website copy for our services page'. PANDA works out the rest and writes it in your brand voice."
            />
          )}
        </div>
      </div>

      {/* Library */}
      <div className="mt-8">
        <h2 className="section-title mb-4">Content library</h2>
        {items.length === 0 ? (
          <p className="card p-6 text-center text-sm text-slate-500">Saved content appears here so you can reuse and adapt it.</p>
        ) : (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {items.map((item) => (
              <div key={item.id} className="card card-hover p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate text-sm font-semibold text-white">{item.title}</h3>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {item.platform ? `${item.platform} · ` : ''}{fmtDate(item.created_at)}
                    </p>
                  </div>
                  <button onClick={() => remove(item.id)} className="btn-ghost text-red-400 hover:text-red-300">
                    <Trash2 size={14} />
                  </button>
                </div>
                <p className="mt-2.5 line-clamp-3 whitespace-pre-wrap text-sm leading-relaxed text-slate-400">{item.body}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {history.length > 0 && (
        <div className="mt-8">
          <h2 className="section-title mb-4">This session</h2>
          <div className="card p-5">
            <div className="space-y-2">
              {history.map((h, i) => (
                <p key={i} className={`text-xs leading-relaxed ${h.role === 'user' ? 'text-slate-400' : 'font-medium text-blue-300'}`}>
                  <span className="mr-2 font-semibold uppercase tracking-wide text-slate-600">{h.role === 'user' ? 'You' : 'PANDA'}</span>
                  {h.text}
                </p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
