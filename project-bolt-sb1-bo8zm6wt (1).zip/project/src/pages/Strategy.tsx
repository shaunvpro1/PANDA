import { useEffect, useRef, useState } from 'react';
import { ArrowUp, Sparkles, Trash2, History, Loader2 } from 'lucide-react';
import { useProfile } from '@/lib/useProfile';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import { strategyReply, type StrategyTurn } from '@/lib/engine';
import { Spinner } from '@/components/ui';

const SUGGESTIONS = [
  'Create a marketing strategy for growing my business',
  'How should I split my monthly budget?',
  'I need more leads — build me a plan',
  'Analyse my competitors and find my edge',
  'Plan a launch campaign for my new offer',
];

export function StrategyPage() {
  const { profile, loading: profileLoading } = useProfile();
  const { data: turns, loading, refetch } = useTable<{ id: string; role: string; body: string; created_at: string }>(
    'strategy_messages',
    { column: 'created_at', ascending: true }
  );
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const thread: StrategyTurn[] = turns.map((t) => ({ role: t.role as 'user' | 'assistant', body: t.body }));

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [turns.length, thinking]);

  const ask = async (text: string) => {
    const instruction = text.trim();
    if (!instruction || thinking) return;
    setThinking(true);
    setError(null);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    const { data: inserted, error: insertError } = await supabase
      .from('strategy_messages')
      .insert({ role: 'user', body: instruction })
      .select()
      .single();
    if (insertError) {
      setError(insertError.message);
      setThinking(false);
      return;
    }
    refetch();

    const history: StrategyTurn[] = [...thread, { role: 'user', body: instruction }];
    const reply = strategyReply(profile, instruction, history.slice(0, -1));
    await new Promise((r) => setTimeout(r, 700));

    const { error: replyError } = await supabase
      .from('strategy_messages')
      .insert({ role: 'assistant', body: reply });
    if (replyError) setError(replyError.message);
    setThinking(false);
    refetch();
  };

  const clear = async () => {
    await supabase.from('strategy_messages').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    refetch();
  };

  if (loading || profileLoading) return <Spinner />;

  const empty = turns.length === 0;

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-4xl flex-col lg:h-[calc(100vh-7rem)]">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-glow">
            <Sparkles size={20} className="text-white" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold tracking-tight text-white sm:text-2xl">Strategy Workspace</h1>
            <p className="text-xs text-slate-500 sm:text-sm">
              Your AI marketing director{profile?.company_name ? ` for ${profile.company_name}` : ''} — brief it on anything
            </p>
          </div>
        </div>
        {!empty && (
          <button onClick={clear} className="btn-ghost text-xs text-slate-500 hover:text-red-400">
            <Trash2 size={14} /> New session
          </button>
        )}
      </div>

      {/* Conversation */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto pr-1">
        {empty && !thinking ? (
          <div className="flex h-full flex-col items-center justify-center px-4 text-center">
            <div className="rounded-2xl bg-navy-800 p-4 text-blue-400"><History size={26} /></div>
            <p className="mt-5 font-display text-lg font-semibold text-white">Brief me like you'd brief a marketing director</p>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-slate-400">
              No forms, no questionnaires. Describe your challenge, your goal, your market — in your own words. I'll respond with a structured plan and we'll refine it together.
            </p>
            <div className="mt-7 flex max-w-xl flex-wrap justify-center gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => ask(s)}
                  className="rounded-full border border-navy-700 bg-navy-900 px-4 py-2 text-xs font-medium text-slate-300 transition-all hover:border-blue-500/50 hover:bg-navy-800 hover:text-white"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-6 pb-6">
            {turns.map((t) => (
              <div key={t.id} className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {t.role === 'user' ? (
                  <div className="max-w-[85%] rounded-2xl rounded-br-md bg-blue-600 px-5 py-3.5 text-sm leading-relaxed text-white sm:max-w-[75%]">
                    {t.body}
                  </div>
                ) : (
                  <div className="w-full max-w-[92%] rounded-2xl rounded-tl-md border border-navy-700/80 bg-navy-900/90 px-6 py-5 sm:max-w-[85%]">
                    <div className="mb-3 flex items-center gap-2 border-b border-navy-800 pb-3">
                      <Sparkles size={14} className="text-blue-400" />
                      <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-blue-400">PANDA Strategy</span>
                    </div>
                    <div className="space-y-1.5">
                      {t.body.split('\n').map((line, i) => {
                        const isHeading = /^[A-Z0-9][A-Z0-9 &—–/.'-]{3,}$/.test(line.trim());
                        const isBullet = line.trim().startsWith('•');
                        const isNumbered = /^\d+\.\s|^[a-z]\.\s|^Weeks? \d/.test(line.trim());
                        if (!line.trim()) return <div key={i} className="h-1.5" />;
                        if (isHeading)
                          return (
                            <p key={i} className="pt-2.5 text-xs font-bold uppercase tracking-[0.14em] text-blue-300">
                              {line.trim()}
                            </p>
                          );
                        return (
                          <p
                            key={i}
                            className={`text-sm leading-relaxed ${isBullet ? 'pl-3 text-slate-300' : isNumbered ? 'pl-2 font-medium text-slate-200' : 'text-slate-300'}`}
                          >
                            {line}
                          </p>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            ))}
            {thinking && (
              <div className="flex justify-start">
                <div className="inline-flex items-center gap-3 rounded-2xl rounded-tl-md border border-navy-700/80 bg-navy-900/90 px-5 py-4">
                  <Loader2 size={16} className="animate-spin text-blue-400" />
                  <span className="text-sm text-slate-400">PANDA is thinking through your brief…</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

      {/* Composer */}
      <div className="mt-4">
        <div className="card border-navy-700 bg-navy-900 p-3 transition-colors focus-within:border-blue-500/60">
          <textarea
            ref={textareaRef}
            rows={1}
            className="max-h-40 w-full resize-none bg-transparent px-3 py-2.5 text-sm leading-relaxed text-slate-200 placeholder:text-slate-500 focus:outline-none"
            placeholder="Describe your marketing challenge, goal or brief — PANDA will do the rest…"
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                ask(input);
              }
            }}
            disabled={thinking}
          />
          <div className="flex items-center justify-between px-2 pb-1">
            <p className="text-[11px] text-slate-600">Enter to send · Shift+Enter for a new line</p>
            <button
              onClick={() => ask(input)}
              disabled={thinking || !input.trim()}
              className="btn-primary gap-1.5 px-4 py-2"
            >
              {thinking ? <Loader2 size={15} className="animate-spin" /> : <ArrowUp size={15} />}
              {thinking ? 'Thinking' : 'Ask PANDA'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
