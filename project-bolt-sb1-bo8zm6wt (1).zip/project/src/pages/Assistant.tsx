import { useEffect, useRef, useState } from 'react';
import { Send, Sparkles, Trash2 } from 'lucide-react';
import { useProfile } from '@/lib/useProfile';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import { assistantReply } from '@/lib/engine';
import type { AssistantMessage } from '@/lib/types';
import { Spinner } from '@/components/ui';

const SUGGESTIONS = [
  'How should I split my marketing budget?',
  'Give me post ideas for next week',
  'How do I generate more leads?',
  'How do I measure my marketing ROI?',
  'Analyse my competitors',
  'Draft an email welcome sequence',
];

export function Assistant() {
  const { profile } = useProfile();
  const { data: messages, loading, refetch } = useTable<AssistantMessage>('assistant_messages', { column: 'created_at', ascending: true });
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages.length, thinking]);

  const ask = async (text: string) => {
    const question = text.trim();
    if (!question || thinking) return;
    setThinking(true);
    setError(null);
    setInput('');

    const insertUser = await supabase
      .from('assistant_messages')
      .insert({ role: 'user', body: question })
      .select()
      .single();
    if (insertUser.error) {
      setError(insertUser.error.message);
      setThinking(false);
      return;
    }
    refetch();

    const reply = assistantReply(profile, question);
    await new Promise((r) => setTimeout(r, 500));
    const insertReply = await supabase
      .from('assistant_messages')
      .insert({ role: 'assistant', body: reply })
      .select()
      .single();
    if (insertReply.error) setError(insertReply.error.message);
    setThinking(false);
    refetch();
  };

  const clear = async () => {
    await supabase.from('assistant_messages').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    refetch();
  };

  if (loading) return <Spinner />;

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col lg:h-[calc(100vh-7rem)]">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 shadow-glow">
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold text-white">AI Marketing Assistant</h1>
            <p className="text-xs text-slate-500">
              Knows your business{profile?.company_name ? `: ${profile.company_name}` : ''} — ask anything about marketing
            </p>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={clear} className="btn-ghost text-xs text-slate-500 hover:text-red-400">
            <Trash2 size={14} /> Clear chat
          </button>
        )}
      </div>

      <div ref={scrollRef} className="card flex-1 overflow-y-auto p-5">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center px-4 text-center">
            <div className="rounded-2xl bg-navy-800 p-4 text-blue-400"><Sparkles size={26} /></div>
            <p className="mt-4 font-display text-lg font-semibold text-white">Your marketing department, on demand</p>
            <p className="mt-1.5 max-w-md text-sm text-slate-400">
              Ask in plain language about strategy, budgets, content, leads or results. Every answer is personalised to your business profile.
            </p>
            <div className="mt-6 flex max-w-lg flex-wrap justify-center gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => ask(s)}
                  className="rounded-full border border-navy-700 bg-navy-800 px-3.5 py-2 text-xs font-medium text-slate-300 transition-colors hover:border-blue-500/50 hover:text-white"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap sm:max-w-[75%] ${
                    m.role === 'user'
                      ? 'rounded-br-md bg-blue-600 text-white'
                      : 'rounded-bl-md border border-navy-700 bg-navy-800/80 text-slate-300'
                  }`}
                >
                  {m.body}
                </div>
              </div>
            ))}
            {thinking && (
              <div className="flex justify-start">
                <div className="rounded-2xl rounded-bl-md border border-navy-700 bg-navy-800/80 px-4 py-3">
                  <div className="flex gap-1.5">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-blue-400 [animation-delay:0ms]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-blue-400 [animation-delay:150ms]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-blue-400 [animation-delay:300ms]" />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

      <div className="mt-4 flex gap-3">
        <input
          className="input flex-1"
          placeholder="Ask your marketing assistant anything…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask(input)}
          disabled={thinking}
        />
        <button onClick={() => ask(input)} disabled={thinking || !input.trim()} className="btn-primary shrink-0 px-4">
          <Send size={17} />
        </button>
      </div>
    </div>
  );
}
