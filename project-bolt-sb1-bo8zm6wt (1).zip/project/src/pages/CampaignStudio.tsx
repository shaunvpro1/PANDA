import { useState } from 'react';
import { Plus, Rocket, Trash2, Megaphone, Play, Pause, CheckCircle2 } from 'lucide-react';
import { useTable } from '@/lib/useTable';
import { supabase } from '@/lib/supabase';
import type { Campaign, CampaignStatus } from '@/lib/types';
import { PageHeader, Spinner, StatusBadge, EmptyState, fmtMoney, fmtDate } from '@/components/ui';

const OBJECTIVES = ['awareness', 'leads', 'sales', 'engagement', 'retention'];

const emptyForm = {
  name: '',
  objective: 'awareness',
  audience: '',
  channels: [] as string[],
  budget: '',
  start_date: '',
  end_date: '',
  description: '',
};

const CHANNELS = ['Facebook', 'Instagram', 'LinkedIn', 'X (Twitter)', 'Google Ads', 'Email', 'TikTok'];

export function CampaignStudio() {
  const { data: campaigns, loading, refetch } = useTable<Campaign>('campaigns', { column: 'created_at' });
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const set = (patch: Partial<typeof emptyForm>) => setForm((f) => ({ ...f, ...patch }));

  const save = async () => {
    if (!form.name.trim()) {
      setError('Give your campaign a name.');
      return;
    }
    setSaving(true);
    setError(null);
    const payload = {
      name: form.name.trim(),
      objective: form.objective,
      audience: form.audience,
      channels: form.channels,
      budget: Number(form.budget) || 0,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      description: form.description,
    };
    const result = editingId
      ? await supabase.from('campaigns').update(payload).eq('id', editingId)
      : await supabase.from('campaigns').insert(payload);
    setSaving(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    refetch();
  };

  const edit = (c: Campaign) => {
    setForm({
      name: c.name,
      objective: c.objective,
      audience: c.audience,
      channels: c.channels,
      budget: String(c.budget),
      start_date: c.start_date ?? '',
      end_date: c.end_date ?? '',
      description: c.description,
    });
    setEditingId(c.id);
    setShowForm(true);
  };

  const setStatus = async (id: string, status: CampaignStatus) => {
    await supabase.from('campaigns').update({ status }).eq('id', id);
    refetch();
  };

  const remove = async (id: string) => {
    await supabase.from('campaigns').delete().eq('id', id);
    refetch();
  };

  if (loading) return <Spinner />;

  const totalBudget = campaigns.reduce((a, c) => a + Number(c.budget), 0);
  const activeCount = campaigns.filter((c) => c.status === 'active').length;

  return (
    <div>
      <PageHeader
        title="Campaign Studio"
        subtitle="Plan, launch and manage marketing campaigns — objectives, audiences, channels and budgets in one place."
      >
        <button
          onClick={() => {
            setShowForm(true);
            setEditingId(null);
            setForm(emptyForm);
          }}
          className="btn-primary"
        >
          <Plus size={16} /> New campaign
        </button>
      </PageHeader>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Total campaigns</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{campaigns.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs uppercase tracking-wider text-slate-500">Active now</p>
          <p className="mt-1 font-display text-2xl font-bold text-emerald-400">{activeCount}</p>
        </div>
        <div className="card p-5 col-span-2 sm:col-span-1">
          <p className="text-xs uppercase tracking-wider text-slate-500">Committed budget</p>
          <p className="mt-1 font-display text-2xl font-bold text-white">{fmtMoney(totalBudget)}</p>
        </div>
      </div>

      {showForm && (
        <div className="card mb-6 border-blue-500/30 p-6">
          <h2 className="section-title mb-5">{editingId ? 'Edit campaign' : 'New campaign'}</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="label">Campaign name</label>
              <input className="input" placeholder="e.g. Spring Launch Push" value={form.name} onChange={(e) => set({ name: e.target.value })} />
            </div>
            <div>
              <label className="label">Objective</label>
              <select className="input capitalize" value={form.objective} onChange={(e) => set({ objective: e.target.value })}>
                {OBJECTIVES.map((o) => (
                  <option key={o} value={o} className="bg-navy-900">{o}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Budget ($)</label>
              <input className="input" type="number" placeholder="e.g. 1500" value={form.budget} onChange={(e) => set({ budget: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Target audience</label>
              <input className="input" placeholder="e.g. Small business owners in retail" value={form.audience} onChange={(e) => set({ audience: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Channels</label>
              <div className="flex flex-wrap gap-2">
                {CHANNELS.map((ch) => {
                  const on = form.channels.includes(ch);
                  return (
                    <button
                      key={ch}
                      onClick={() => set({ channels: on ? form.channels.filter((c) => c !== ch) : [...form.channels, ch] })}
                      className={`rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors ${
                        on ? 'bg-blue-600 text-white' : 'bg-navy-800 text-slate-400 border border-navy-700 hover:text-white'
                      }`}
                    >
                      {ch}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="label">Start date</label>
              <input className="input" type="date" value={form.start_date} onChange={(e) => set({ start_date: e.target.value })} />
            </div>
            <div>
              <label className="label">End date</label>
              <input className="input" type="date" value={form.end_date} onChange={(e) => set({ end_date: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Description</label>
              <textarea className="input min-h-[80px]" placeholder="What is this campaign about, and what does success look like?" value={form.description} onChange={(e) => set({ description: e.target.value })} />
            </div>
          </div>
          {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
          <div className="mt-5 flex gap-3">
            <button onClick={save} disabled={saving} className="btn-primary">
              {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create campaign'}
            </button>
            <button onClick={() => { setShowForm(false); setEditingId(null); }} className="btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      {campaigns.length === 0 && !showForm ? (
        <EmptyState
          icon={<Rocket size={24} />}
          title="No campaigns yet"
          hint="Create your first campaign — set an objective, audience, channels and budget, then move it to Active when you're ready to launch."
        />
      ) : (
        <div className="space-y-4">
          {campaigns.map((c) => (
            <div key={c.id} className="card card-hover p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="font-display font-semibold text-white">{c.name}</h3>
                    <StatusBadge status={c.status} />
                    <span className="badge bg-navy-500/25 text-blue-300 capitalize">{c.objective}</span>
                  </div>
                  {c.description && <p className="mt-1.5 text-sm text-slate-400 line-clamp-2">{c.description}</p>}
                  <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1"><Megaphone size={13} /> {fmtMoney(Number(c.budget))}</span>
                    <span>{fmtDate(c.start_date)} → {fmtDate(c.end_date)}</span>
                    {c.audience && <span className="truncate">Audience: {c.audience}</span>}
                  </div>
                  {c.channels.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {c.channels.map((ch) => (
                        <span key={ch} className="rounded-full bg-blue-500/10 px-2.5 py-1 text-[11px] font-medium text-blue-300">{ch}</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {c.status !== 'active' && (
                    <button onClick={() => setStatus(c.id, 'active')} className="btn-ghost text-emerald-400 hover:text-emerald-300" title="Activate">
                      <Play size={15} /> Activate
                    </button>
                  )}
                  {c.status === 'active' && (
                    <button onClick={() => setStatus(c.id, 'paused')} className="btn-ghost text-amber-400 hover:text-amber-300" title="Pause">
                      <Pause size={15} /> Pause
                    </button>
                  )}
                  {c.status !== 'completed' && (
                    <button onClick={() => setStatus(c.id, 'completed')} className="btn-ghost" title="Mark completed">
                      <CheckCircle2 size={15} />
                    </button>
                  )}
                  <button onClick={() => edit(c)} className="btn-ghost text-xs">Edit</button>
                  <button onClick={() => remove(c.id)} className="btn-ghost text-red-400 hover:text-red-300">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
