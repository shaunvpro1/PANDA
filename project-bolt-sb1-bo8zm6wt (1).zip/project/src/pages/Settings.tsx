import { useState } from 'react';
import { Save, Building2, CheckCircle2, Crown, Sparkles, UserCog } from 'lucide-react';
import { useProfile } from '@/lib/useProfile';
import { PageHeader, Spinner } from '@/components/ui';

const VOICES = ['Professional', 'Friendly', 'Bold', 'Playful', 'Luxury'];

export function Settings() {
  const { profile, loading, save } = useProfile();
  const [form, setForm] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (loading) return <Spinner />;
  if (!profile) return <p className="text-slate-400">Profile not available.</p>;

  const value = (key: string, fallback: string | number) =>
    form[key] ?? String(fallback);

  const set = (key: string, val: string) => {
    setForm((f) => ({ ...f, [key]: val }));
    setSaved(false);
  };

  const submit = async () => {
    setSaving(true);
    setError(null);
    const err = await save({
      company_name: value('company_name', profile.company_name).trim() || 'My Business',
      industry: value('industry', profile.industry).trim(),
      products_services: value('products_services', profile.products_services).trim(),
      target_audience: value('target_audience', profile.target_audience).trim(),
      brand_voice: value('brand_voice', profile.brand_voice),
      website: value('website', profile.website).trim(),
      unique_value: value('unique_value', profile.unique_value).trim(),
      monthly_budget: Number(value('monthly_budget', profile.monthly_budget)) || 0,
    });
    setSaving(false);
    if (err) {
      setError(err.message);
      return;
    }
    setForm({});
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const completeness = [
    profile.industry,
    profile.products_services,
    profile.target_audience,
    profile.unique_value,
    profile.website,
  ].filter((v) => v && v.trim()).length;
  const pct = Math.round((completeness / 5) * 100);

  return (
    <div>
      <PageHeader
        title="Settings"
        subtitle="Your business profile powers everything — the AI assistant, strategy generator and content creator all personalise from these details."
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="card p-6 xl:col-span-2">
          <div className="mb-5 flex items-center gap-2">
            <Building2 size={17} className="text-blue-400" />
            <h2 className="section-title">Business profile</h2>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Company name</label>
              <input className="input" value={value('company_name', profile.company_name)} onChange={(e) => set('company_name', e.target.value)} />
            </div>
            <div>
              <label className="label">Industry</label>
              <input className="input" placeholder="e.g. Boutique fitness studio" value={value('industry', profile.industry)} onChange={(e) => set('industry', e.target.value)} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Products & services</label>
              <textarea className="input min-h-[70px]" placeholder="What do you sell or provide?" value={value('products_services', profile.products_services)} onChange={(e) => set('products_services', e.target.value)} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">Target audience</label>
              <textarea className="input min-h-[70px]" placeholder="Who are your ideal customers?" value={value('target_audience', profile.target_audience)} onChange={(e) => set('target_audience', e.target.value)} />
            </div>
            <div>
              <label className="label">Brand voice</label>
              <select className="input" value={value('brand_voice', profile.brand_voice)} onChange={(e) => set('brand_voice', e.target.value)}>
                {VOICES.map((v) => (
                  <option key={v} value={v} className="bg-navy-900">{v}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Website</label>
              <input className="input" placeholder="https://…" value={value('website', profile.website)} onChange={(e) => set('website', e.target.value)} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">What makes you different?</label>
              <textarea className="input min-h-[70px]" placeholder="Your unique value — the reason customers choose you" value={value('unique_value', profile.unique_value)} onChange={(e) => set('unique_value', e.target.value)} />
            </div>
            <div>
              <label className="label">Monthly marketing budget ($)</label>
              <input className="input" type="number" value={value('monthly_budget', profile.monthly_budget)} onChange={(e) => set('monthly_budget', e.target.value)} />
            </div>
          </div>
          {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
          <div className="mt-5 flex items-center gap-3">
            <button onClick={submit} disabled={saving} className="btn-primary">
              <Save size={15} /> {saving ? 'Saving…' : 'Save profile'}
            </button>
            {saved && (
              <span className="inline-flex items-center gap-1.5 text-sm font-medium text-emerald-400">
                <CheckCircle2 size={15} /> Saved
              </span>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="card p-6">
            <div className="flex items-center justify-between">
              <h2 className="section-title">Profile strength</h2>
              <span className={`font-display text-xl font-bold ${pct === 100 ? 'text-emerald-400' : 'text-blue-400'}`}>{pct}%</span>
            </div>
            <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-navy-800">
              <div className="h-full rounded-full bg-gradient-to-r from-blue-600 to-blue-400 transition-all duration-500" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-3 text-sm leading-relaxed text-slate-400">
              {pct === 100
                ? 'Your profile is complete — the AI assistant can fully personalise its strategies and content.'
                : 'Fill in the remaining details so the AI assistant can write sharper strategies and better content for your business.'}
            </p>
          </div>

          <div className="card p-6">
            <div className="flex items-center gap-2">
              <Crown size={17} className="text-amber-400" />
              <h2 className="section-title">Plan</h2>
            </div>
            <div className="mt-4 rounded-xl border border-blue-500/30 bg-blue-500/5 p-4">
              <p className="text-sm font-semibold text-white">Founding Member</p>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">
                Full access to every PANDA module during launch. Tiered subscriptions, business accounts and premium managed services arrive soon.
              </p>
            </div>
            <div className="mt-4 space-y-2.5 text-sm text-slate-400">
              {['All 9 modules included', 'Unlimited AI assistant use', 'Unlimited content generation', 'Priority support'].map((f) => (
                <p key={f} className="inline-flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-400" /> {f}
                </p>
              ))}
            </div>
          </div>

          <div className="card p-6">
            <div className="flex items-center gap-2">
              <Sparkles size={17} className="text-blue-400" />
              <h2 className="section-title">How personalisation works</h2>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-slate-400">
              Every generated strategy, post, email and assistant answer draws on your company, industry, audience, brand voice and budget above. The richer your profile, the sharper the output.
            </p>
            <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-slate-500">
              <UserCog size={13} /> Changes apply instantly across the platform.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
