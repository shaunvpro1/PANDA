import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';

export function useTable<T>(table: string, order: { column: string; ascending?: boolean } | null = null) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refetch = useCallback(async () => {
    let query = supabase.from(table).select('*');
    if (order) query = query.order(order.column, { ascending: order.ascending ?? false });
    const { data: rows, error: err } = await query;
    if (err) setError(err.message);
    else {
      setData((rows ?? []) as T[]);
      setError(null);
    }
    setLoading(false);
  }, [table, order?.column, order?.ascending]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { data, loading, error, refetch };
}
