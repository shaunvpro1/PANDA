export type CampaignStatus = 'draft' | 'active' | 'paused' | 'completed';
export type LeadStatus = 'new' | 'contacted' | 'qualified' | 'won' | 'lost';
export type ContentType =
  | 'social_post'
  | 'email'
  | 'ad_copy'
  | 'website'
  | 'product_description'
  | 'campaign_concept';

export interface BusinessProfile {
  id: number;
  company_name: string;
  industry: string;
  products_services: string;
  target_audience: string;
  brand_voice: string;
  website: string;
  unique_value: string;
  monthly_budget: number;
  updated_at: string;
}

export interface Strategy {
  id: string;
  title: string;
  positioning: string;
  audience: string;
  competitors: string;
  objectives: string;
  budget_notes: string;
  channels: string[];
  status: string;
  created_at: string;
}

export interface Campaign {
  id: string;
  name: string;
  objective: string;
  audience: string;
  channels: string[];
  budget: number;
  start_date: string | null;
  end_date: string | null;
  status: CampaignStatus;
  description: string;
  created_at: string;
}

export interface ContentItem {
  id: string;
  title: string;
  content_type: ContentType;
  platform: string;
  body: string;
  campaign_id: string | null;
  status: string;
  created_at: string;
}

export interface SocialPost {
  id: string;
  platform: string;
  content: string;
  scheduled_at: string | null;
  status: 'draft' | 'scheduled' | 'published';
  impressions: number;
  likes: number;
  comments: number;
  clicks: number;
  campaign_id: string | null;
  created_at: string;
}

export interface Lead {
  id: string;
  name: string
  email: string;
  company: string;
  source: string;
  status: LeadStatus;
  value: number;
  notes: string;
  created_at: string;
}

export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  body: string;
  created_at: string;
}

export interface Metric {
  id: string;
  day: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
}
