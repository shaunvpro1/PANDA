import type { BusinessProfile, ContentType } from './types';

const VOICE_OPENERS: Record<string, string[]> = {
  Professional: [
    'Discover the difference true expertise makes.',
    'Built for businesses that take growth seriously.',
  ],
  Friendly: [
    "We're here to make things simple for you.",
    "Great things happen when we work together.",
  ],
  Bold: [
    'Stop blending in. Start standing out.',
    'Your competitors will hate this.',
  ],
  Playful: [
    "Warning: results may cause smiling.",
    "The secret ingredient? Actually caring.",
  ],
  Luxury: [
    'Crafted exclusively for those who expect more.',
    'Where refinement meets results.',
  ],
};

const DEFAULT_OPENERS = VOICE_OPENERS.Professional;

function openers(voice: string): string[] {
  return VOICE_OPENERS[voice] ?? DEFAULT_OPENERS;
}

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function businessBrief(bp: BusinessProfile | null): string {
  if (!bp) return 'a growing business';
  const parts = [bp.company_name];
  if (bp.industry) parts.push(`a ${bp.industry} business`);
  return parts.join(', ');
}

export interface GenerateContentInput {
  type: string;
  topic: string;
  platform?: string;
  tone?: string;
  voice?: string;
  keywords?: string;
  audience?: string;
}

export function generateContent(
  bp: BusinessProfile | null,
  input: GenerateContentInput
): { title: string; body: string } {
  const company = bp?.company_name || 'our brand';
  const value = bp?.unique_value || 'quality you can count on';
  const audience = input.audience || bp?.target_audience || 'customers who expect the best';
  const products = bp?.products_services || 'our products and services';
  const voice = input.voice || input.tone || bp?.brand_voice || 'Professional';
  const seed = hash(input.topic + input.type + Date.now().toString());
  const opener = pick(openers(voice), seed);
  const kw = (input.keywords || '')
    .split(',')
    .map((k) => k.trim())
    .filter(Boolean);

  const hashtagLine =
    kw.length > 0
      ? '\n\n' + kw.map((k) => '#' + k.replace(/\s+/g, '')).join(' ')
      : '';

  switch (input.type) {
    case 'social_post': {
      const platform = input.platform || 'Instagram';
      const limit = platform === 'X (Twitter)' ? 240 : 500;
      const body = `${opener}\n\n${input.topic} — now easier than ever with ${company}.\n\nWe help ${audience} get real results with ${products}. ${value.charAt(0).toUpperCase() + value.slice(1)}.\n\n👉 Learn more at ${bp?.website || 'our website'}${hashtagLine}`;
      return {
        title: `${platform} post: ${input.topic}`,
        body: body.slice(0, limit) + (body.length > limit ? '\n\n(Trimmed to platform limit)' : ''),
      };
    }
    case 'email': {
      const body = `Subject: ${input.topic} — something worth your time\n\nHi there,\n\n${opener}\n\nAt ${company}, we've been working on something we think you'll love. If you've been looking for ${products} that actually deliver, this is it.\n\nHere's what's in it for you:\n• ${value.charAt(0).toUpperCase() + value.slice(1)}\n• Built specifically for ${audience}\n• No hassle, no pressure — just results\n\nSee the details here: ${bp?.website || 'our website'}\n\nWarm regards,\nThe ${company} Team${hashtagLine}`;
      return { title: `Email: ${input.topic}`, body };
    }
    case 'ad_copy': {
      const body = `HEADLINE: ${input.topic} | ${company}\n\nPRIMARY TEXT: ${opener} ${company} delivers ${products} designed for ${audience}. ${value.charAt(0).toUpperCase() + value.slice(1)}.\n\nCTA: Get started today → ${bp?.website || 'Learn more'}${hashtagLine}`;
      return { title: `Ad copy: ${input.topic}`, body };
    }
    case 'website': {
      const body = `HERO SECTION\nHeadline: ${input.topic}\nSubheadline: ${company} — ${value}.\nPrimary CTA: Get Started   Secondary CTA: Learn More\n\nABOUT SECTION\n${company} serves ${audience} with ${products}. We believe great marketing starts with genuinely understanding the customer — and everything we do is built around that principle.\n\nWHY CHOOSE US\n• Tailored for ${audience}\n• Proven results and transparent pricing\n• Dedicated support at every step\n\nCLOSING CTA\nReady to see the difference? Visit ${bp?.website || 'our website'}.`;
      return { title: `Website copy: ${input.topic}`, body };
    }
    case 'product_description': {
      const body = `${input.topic}\n\n${opener}\n\nMeet ${input.topic} from ${company} — crafted for ${audience} who refuse to compromise. Key benefits:\n\n1. ${value.charAt(0).toUpperCase() + value.slice(1)}\n2. Designed around how you actually work\n3. Backed by our commitment to quality\n\nIdeal for: ${audience}\nPart of our range: ${products}`;
      return { title: `Product description: ${input.topic}`, body };
    }
    default: {
      const body = `CAMPAIGN CONCEPT: ${input.topic}\n\nBIG IDEA\n${opener} Position ${company} as the obvious choice for ${audience}.\n\nKEY MESSAGE\n${value.charAt(0).toUpperCase() + value.slice(1)} — and ${products} that prove it.\n\nEXECUTION\n1. Launch hero content across your core channels\n2. Follow with testimonial and behind-the-scenes posts\n3. Retarget engaged audiences with a limited-time offer\n4. Close with a results-focused email sequence\n\nSUCCESS METRICS\nReach, engagement rate, click-through rate, leads generated.`;
      return { title: `Campaign concept: ${input.topic}`, body };
    }
  }
}

// ---------------------------------------------------------------------------
// Content brief interpreter: reads any free-form content request and decides
// the content type, audience, tone and platform, so the user never needs a form.
// ---------------------------------------------------------------------------

const CONTENT_TYPES: { type: ContentType; label: string; words: string[] }[] = [
  { type: 'email', label: 'Email', words: ['email', 'newsletter', 'mail out', 'mailout', 'mailchimp', 'inbox'] },
  { type: 'ad_copy', label: 'Ad copy', words: ['ad ', 'advert', 'advertisement', 'ads ', 'ad copy', 'ppc', 'sponsored', 'banner', 'google ads', 'paid social'] },
  { type: 'website', label: 'Website copy', words: ['website', 'landing page', 'homepage', 'home page', 'web page', 'webpage', 'site copy', 'about page', 'hero section'] },
  { type: 'product_description', label: 'Product description', words: ['product description', 'product page', 'describe the product', 'listing', 'service description', 'product write-up', 'catalogue'] },
  { type: 'campaign_concept', label: 'Campaign concept', words: ['campaign', 'concept', 'launch idea', 'big idea', 'promotion plan', 'creative direction'] },
  { type: 'social_post', label: 'Social media post', words: ['post', 'tweet', 'thread', 'caption', 'instagram', 'facebook', 'linkedin', 'tiktok', 'x.com', 'twitter', 'social'] },
];

const TONES: { tone: string; words: string[] }[] = [
  { tone: 'Bold', words: ['bold', 'punchy', 'edgy', 'aggressive', 'direct', 'fearless', 'provocative'] },
  { tone: 'Playful', words: ['playful', 'fun', 'cheeky', 'light-hearted', 'lighthearted', 'witty', 'humor', 'humour', 'casual'] },
  { tone: 'Luxury', words: ['luxury', 'luxurious', 'premium', 'elegant', 'sophisticated', 'exclusive', 'high-end', 'refined', 'aspirational'] },
  { tone: 'Friendly', words: ['friendly', 'warm', 'approachable', 'conversational', 'relatable', 'personal', 'human'] },
  { tone: 'Professional', words: ['professional', 'corporate', 'formal', 'b2b', 'credible', 'authoritative'] },
];

const PLATFORMS = ['Instagram', 'Facebook', 'LinkedIn', 'X (Twitter)', 'TikTok'];
const PLATFORM_ALIASES: Record<string, string> = {
  instagram: 'Instagram',
  insta: 'Instagram',
  facebook: 'Facebook',
  meta: 'Facebook',
  linkedin: 'LinkedIn',
  tiktok: 'TikTok',
  twitter: 'X (Twitter)',
  'x / twitter': 'X (Twitter)',
  'x (twitter)': 'X (Twitter)',
  x: 'X (Twitter)',
};

export interface InterpretedBrief {
  type: ContentType;
  typeLabel: string;
  topic: string;
  platform: string;
  tone: string;
  audience: string;
  keywords: string[];
}

export function interpretBrief(
  bp: BusinessProfile | null,
  brief: string,
  overrides?: { type?: string; platform?: string; tone?: string }
): InterpretedBrief {
  const q = brief.toLowerCase();

  let type: ContentType = 'social_post';
  let typeLabel = 'Social media post';
  if (overrides?.type) {
    const found = CONTENT_TYPES.find((t) => t.type === overrides.type);
    if (found) {
      type = found.type;
      typeLabel = found.label;
    }
  } else {
    for (const ct of CONTENT_TYPES) {
      if (ct.words.some((w) => q.includes(w))) {
        type = ct.type;
        typeLabel = ct.label;
        break;
      }
    }
  }

  let platform = '';
  if (overrides?.platform) {
    platform = overrides.platform;
  } else {
    for (const p of PLATFORMS) {
      if (q.includes(p.toLowerCase())) {
        platform = p;
        break;
      }
    }
    if (!platform) {
      for (const [alias, canonical] of Object.entries(PLATFORM_ALIASES)) {
        if (new RegExp(`\\b${alias}\\b`).test(q)) {
          platform = canonical;
          break;
        }
      }
    }
  }

  let tone = '';
  if (overrides?.tone) {
    tone = overrides.tone;
  } else {
    for (const t of TONES) {
      if (t.words.some((w) => q.includes(w))) {
        tone = t.tone;
        break;
      }
    }
    if (!tone) tone = bp?.brand_voice || 'Professional';
  }

  let audience = '';
  const audMatch = brief.match(/for\s+((?:small|local|high-end|busy|young|affluent|new|existing|prospective)?\s?[a-z]+(?:\s+[a-z]+){0,4})/i);
  const audienceCue = /(audience|aimed at|targeting|speak to|for)\b/i;
  if (audMatch && audienceCue.test(audMatch[0])) {
    audience = audMatch[1].trim().replace(/[.,;]$/, '');
  }
  if (!audience) audience = bp?.target_audience || '';

  const keywords = (q.match(/#[a-z0-9]+/g) ?? []).map((k) => k.slice(1));

  const cleaned = brief
    .replace(/#[a-z0-9]+/gi, '')
    .replace(/^\s*(write|create|draft|generate|make|compose|produce)\s+(me\s+)?(a|an|the)?\s*/i, '')
    .replace(/^\s*(please\s+)/i, '')
    .trim();

  const topic = cleaned.length > 0 ? cleaned : brief.trim();

  return { type, typeLabel, topic, platform, tone, audience, keywords };
}

// ---------------------------------------------------------------------------
// Follow-up refinement: applies an instruction to previously generated content.
// ---------------------------------------------------------------------------

export interface RefineInput {
  instruction: string;
  title: string;
  body: string;
}

export function refineContent(
  bp: BusinessProfile | null,
  input: RefineInput
): { title: string; body: string } {
  const q = input.instruction.toLowerCase();
  const body = input.body;
  const has = (...words: string[]) => words.some((w) => q.includes(w));
  const company = bp?.company_name || 'our brand';

  const truncated = (s: string) => (s.length > 100 ? s.slice(0, 100).trim() + '…' : s.trim());

  if (has('shorter', 'shorten', 'condense', 'tighten', 'trim', 'cut down', 'more concise')) {
    const sentences = body
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
    const condensed = sentences
      .filter((l, i) => !(l.startsWith('•') && i > 2) )
      .map((l) =>
        l
          .replace(/^(We help|Built specifically|No hassle[^—]*—)\s*/i, '')
          .replace(/\s{2,}/g, ' ')
      )
      .slice(0, Math.max(4, Math.ceil(sentences.length * 0.55)))
      .join('\n');
    return { title: input.title, body: condensed };
  }

  if (has('longer', 'expand', 'more detail', 'elaborate', 'flesh out', 'more depth', 'build on')) {
    const extra = `\n\nA CLOSER LOOK\nWhat sets ${company} apart is the way we work with you: clear communication, honest timelines, and a genuine interest in your outcome. Every ${bp?.products_services || 'engagement'} starts with understanding where you are and where you want to be — then we build the bridge.\n\nTHE DETAILS THAT MATTER\n• No jargon, no guesswork — you always know what's happening and why\n• Flexible to your pace and priorities\n• Straightforward pricing, agreed up front\n\nREADY WHEN YOU ARE\nFind out more at ${bp?.website || 'our website'} — we'd love to show you what's possible.`;
    return { title: input.title, body: body + extra };
  }

  if (has('friendlier', 'warmer', 'more casual', 'more friendly', 'softer', 'conversational')) {
    const rewritten = body.replace(/Discover the difference true expertise makes\.|Built for businesses that take growth seriously\./g, "Great things happen when we work together — and we'd love to show you.");
    return { title: input.title, body: `Hi there,\n\n${rewritten.replace(/^Hi there,\n\n/, '')}\n\nP.S. Any questions at all, just reply — a real person reads every message.` };
  }

  if (has('more professional', 'formal', 'more corporate', 'serious')) {
    return {
      title: input.title,
      body: body.replace(/Great things happen when we work together\.|Warning: results may cause smiling\.|Stop blending in\. Start standing out\./g, 'Discover the difference true expertise makes.') + '\n\nWe welcome the opportunity to discuss how this aligns with your objectives.',
    };
  }

  if (has('more bold', 'bolder', 'punchier', 'edgier', 'stronger hook', 'more attention')) {
    return { title: input.title, body: `Stop scrolling. This one matters.\n\n${body}` };
  }

  if (has('emoji')) {
    const withEmoji = body
      .replace(/\n\n/g, '\n\n')
      .replace(/^(HEADLINE|SUBJECT)/m, '$1')
      .concat('\n\n✨ Key benefits • 💬 Real results • 🚀 Ready when you are');
    return { title: input.title, body: withEmoji };
  }

  if (has('cta', 'call to action', 'call-to-action')) {
    return { title: input.title, body: body + `\n\nNEXT STEP\nAct now: ${bp?.website || 'visit our website'} — limited availability, genuine results.` };
  }

  if (has('headline', 'subject line', 'title')) {
    const options = `HEADLINE OPTIONS\n1. ${truncated(input.title.replace(/^[A-Za-z ]+:\s*/, ''))}\n2. The smarter way to ${bp?.products_services || 'get results'}\n3. ${company}: where quality meets momentum\n4. Your search ends here\n5. Finally — ${bp?.unique_value || 'the difference you were looking for'}`;
    return { title: input.title, body: body + `\n\n${options}` };
  }

  return {
    title: input.title,
    body: `${body}\n\nREFINED — ${truncated(input.instruction)}\nPolished for clarity, tone and impact. Review, tweak and ship with confidence.`,
  };
}

export interface StrategyDraftInput {
  goal: string;
  budget: number;
}

export function draftStrategy(
  bp: BusinessProfile | null,
  input: StrategyDraftInput
): {
  title: string;
  positioning: string;
  audience: string;
  competitors: string;
  objectives: string;
  budget_notes: string;
  channels: string[];
} {
  const company = bp?.company_name || 'your business';
  const industry = bp?.industry || 'your market';
  const audience = bp?.target_audience || 'your ideal customers';
  const value = bp?.unique_value || 'genuine customer value';
  const budget = input.budget || bp?.monthly_budget || 2000;

  const channelSplit = [
    { channel: 'Social media (organic + paid)', share: 0.4 },
    { channel: 'Search / Google Ads', share: 0.3 },
    { channel: 'Email marketing', share: 0.15 },
    { channel: 'Content & partnerships', share: 0.15 },
  ];

  return {
    title: `${input.goal} — Strategy for ${company}`,
    positioning: `${company} should own the position of "${value}" within the ${industry} market. Every message reinforces one promise: the smartest choice for ${audience}. Avoid competing on price; compete on clarity, trust and demonstrated results.`,
    audience: `Primary: ${audience}. Build 2-3 segments — decision-makers ready to buy now, researchers comparing options, and past customers with repeat potential. Tailor proof points and offers to each segment.`,
    competitors: `Identify 3-5 direct competitors in ${industry}. Audit their messaging, pricing pages and social presence. Look for the gap: what customers complain about in their reviews is your opportunity to differentiate.`,
    objectives: `Primary goal: ${input.goal}. 90-day targets:\n1. Grow qualified leads by 20%\n2. Lift engagement rate above 4% on core channels\n3. Convert at least 5% of pipeline into paying customers\n4. Establish a consistent weekly publishing rhythm`,
    budget_notes: `Recommended monthly budget: $${budget.toLocaleString()}. Suggested split:\n` + channelSplit
      .map((c) => `• ${c.channel}: $${Math.round(budget * c.share).toLocaleString()} (${Math.round(c.share * 100)}%)`)
      .join('\n') + `\n\nHold 10% flexibility for testing new channels and doubling down on what performs.`,
    channels: channelSplit.map((c) => c.channel),
  };
}

export interface StrategyTurn {
  role: 'user' | 'assistant';
  body: string;
}

function recentThreadSummary(thread: StrategyTurn[]): string {
  const recent = thread.slice(-6);
  return recent
    .map((t) => `${t.role === 'user' ? 'Client asked' : 'You advised'}: ${t.body.slice(0, 160).replace(/\n+/g, ' ')}`)
    .join('\n');
}

// ---------------------------------------------------------------------------
// Brief-driven strategist. Facts are extracted from the user's own words and
// every strategy is composed from them. Missing facts become stated
// assumptions — never invented. Used as the fallback when the AI model
// (edge function) is unavailable; the model path is preferred.
// ---------------------------------------------------------------------------

interface BriefFacts {
  company: string | null;
  products: string[];
  audiences: string[];
  goals: string[];
  budget: number | null;
  timeline: string | null;
  market: string[];
  channels: string[];
  locations: string[];
}

const VERB_NOISE = /^(grow|sell|market|launch|increase|improve|get|find|build|create|write|make|know|understand|see|do|be|have|use|run|start|win|reach|drive|boost|scale)/i;

function extractFacts(brief: string): BriefFacts {
  const text = brief.replace(/\s+/g, ' ').trim();
  const t = text.toLowerCase();

  const grab = (re: RegExp, max = 6): string[] => {
    const out: string[] = [];
    const g = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
    let m: RegExpExecArray | null;
    while ((m = g.exec(text)) !== null && out.length < max) {
      const v = m[1]?.trim().replace(/[.,;:]$/, '');
      if (v && v.length > 2 && !out.some((o) => o.toLowerCase() === v.toLowerCase())) out.push(v);
      if (m.index === g.lastIndex) g.lastIndex++;
    }
    return out;
  };

  const company =
    grab(/(?:my business|my company|we are|we're|i run|our company|company called|agency called|brand called|business called)\s+([A-Z][\w&'’-]*(?:\s+[A-Z][\w&'’-]*){0,3})/, 1)[0] ?? null;

  const products = grab(
    /(?:we sell|we offer|we make|we provide|we do|i sell|i offer|i make|selling|offering|specialis(?:e|ing) in|specializ(?:e|ing) in|our products? (?:is|are|include[sd]?)|our services? (?:is|are|include[sd]?))\s+([^.;]{3,90})/i
  );

  const audiences = grab(
    /(?:customers?|clients?|audience|targeting|aimed at|speaking to|speak to|market to)\s+(?:are\s+|is\s+|mostly\s+|mainly\s+|predominantly\s+)?((?:small |local |young |busy |affluent |wealthy |new |existing |prospective |high-end |premium |older |female |male )?[a-z]+(?:\s+[a-z]+){0,4})/i
  ).filter((a) => !VERB_NOISE.test(a));

  const goals = grab(/(?:want to|wants to|hoping to|need to|goal is to|objective is to|aim(?:ing)? to|trying to|looking to|would like to)\s+([^.;]{4,90})/i);

  const budgetMatch =
    text.match(/(?:budget|spend|spending)[^0-9$]{0,24}\$?\s?([\d][\d,]*(?:\.\d+)?)\s*(k\b|per month|\/month|monthly|a month|p\/m|per week|\/week|weekly)?/i) ??
    text.match(/\$\s?([\d][\d,]*(?:\.\d+)?)\s*(per month|\/month|monthly|a month|p\/m|k\b)?/i);
  let budget: number | null = null;
  if (budgetMatch) {
    let n = Number(budgetMatch[1].replace(/,/g, ''));
    if (/k\b/i.test(budgetMatch[0] ?? '')) n *= 1000;
    if (/week/i.test(budgetMatch[0] ?? '')) n = Math.round(n * 4.33);
    if (n > 0 && n < 10_000_000) budget = Math.round(n);
  }

  const timelineMatch = text.match(
    /(?:in|within|over|by|next)\s+((?:\d+|two|three|six|twelve)\s*(?:days?|weeks?|months?|quarters?)|q[1-4]|next quarter|this year|next year|by (?:january|february|march|april|may|june|july|august|september|october|november|december))/i
  );

  const market = grab(
    /(?:competitors?|rivals?|the market|our market|industry|season|seasonality|downturn|recession|demand|economy)\s*(?:is|are|has been|have been|feels|looks)\s*([^.;]{4,90})/i
  );

  const channelMap: [RegExp, string][] = [
    [/\binstagram\b/, 'Instagram'],
    [/\bfacebook\b/, 'Facebook'],
    [/\blinkedin\b/, 'LinkedIn'],
    [/\btiktok\b/, 'TikTok'],
    [/\b(?:google|search) ads?\b/, 'Google Ads'],
    [/\bemail(?:\s+marketing)?\b/, 'Email'],
    [/\btwitter\b|\bx\.com\b/, 'X (Twitter)'],
  ];
  const channels = channelMap.filter(([re]) => re.test(t)).map(([, name]) => name);

  const locations = grab(/(?:in|around|near|across|based in)\s+((?:[A-Z][a-z]+\s?){1,3})/, 2);

  return { company, products, audiences, goals, budget, timeline: timelineMatch?.[1] ?? null, market, channels, locations };
}

function qualityPass(raw: string): string {
  const seen = new Set<string>();
  const lines = raw
    .split('\n')
    .map((l) => l.replace(/\s{2,}/g, ' ').trimEnd())
    .filter((l) => {
      const key = l.trim().toLowerCase();
      if (key.length > 30 && seen.has(key)) return false;
      if (key.length > 30) seen.add(key);
      return true;
    });
  return lines.join('\n');
}

function listSentence(items: string[], fallback: string): string {
  const clean = items.filter((i) => i && i.length > 2).slice(0, 4);
  if (clean.length === 0) return fallback;
  if (clean.length === 1) return clean[0];
  return clean.slice(0, -1).join(', ') + ' and ' + clean[clean.length - 1];
}

function composeStrategy(
  bp: BusinessProfile | null,
  brief: string,
  facts: BriefFacts,
  isFollowUp: boolean
): string {
  const company = facts.company ?? bp?.company_name ?? 'your business';
  const profileAudience = bp?.target_audience || '';
  const audience = listSentence(facts.audiences, profileAudience || 'your existing customer base');
  const products = listSentence(facts.products, bp?.products_services || 'your core products and services');
  const goalText = facts.goals.length > 0 ? facts.goals.map((g) => g.replace(/^to\s+/i, '')).join('; priority: ') : null;
  const budget = facts.budget ?? (bp?.monthly_budget > 0 ? bp!.monthly_budget : null);
  const value = bp?.unique_value || '';
  const industry = bp?.industry || '';

  const assumptions: string[] = [];
  if (!facts.company) assumptions.push(`"${company}" is the business in question — taken from your ${bp ? 'profile' : 'defaults'}; correct me if this strategy is for something else.`);
  if (facts.audiences.length === 0 && !profileAudience) assumptions.push('No target customer was described — the plan assumes your current customer base; naming 1–2 specific customer types would sharpen it.');
  if (facts.audiences.length === 0 && profileAudience) assumptions.push(`Audience not stated in the brief — using "${profileAudience}" from your profile.`);
  if (facts.budget === null) assumptions.push(budget ? `No budget given — using ${budget.toLocaleString()}/month from your profile.` : 'No budget was given — recommendations avoid paid spend until you confirm an amount.');
  if (facts.timeline === null) assumptions.push('No timeline was given — the plan is structured as 90 days, the shortest window in which marketing reliably shows results.');
  if (facts.products.length === 0 && !bp?.products_services) assumptions.push('Products/services were not described — substitute your actual offer where the plan says "' + products + '".');

  const priorities: string[] = [];
  const g = facts.goals.join(' ').toLowerCase();
  if (/lead|customer|client|enquir|inquir|sales|book|sign/.test(g)) {
    priorities.push(`Priority 1 — Build one reliable lead path. A single, specific offer for ${audience}, promoted where they already are, with every enquiry captured and source-tagged in the Leads workspace.`);
  }
  if (/launch|new |campaign|event|promotion|sale|open/.test(g)) {
    priorities.push(`Priority 1 — Stage the launch. Three waves: announcement, proof, urgency close — each with distinct creative, so the campaign has shape instead of one loud post.`);
  }
  if (/brand|awareness|visibility|known|recogni/.test(g)) {
    priorities.push(`Priority 1 — Own one message. ${company} should stand for one thing to ${audience}; every asset repeats it until you're bored of it and they finally remember it.`);
  }
  if (/retain|loyal|repeat|churn|existing/.test(g)) {
    priorities.push(`Priority 1 — Reactivate what you already have. A simple outreach to past customers costs nothing and typically outperforms cold acquisition in week one.`);
  }
  if (priorities.length === 0) {
    priorities.push(`Priority 1 — Sharpen the offer for ${audience}: one specific promise, one obvious reason to act now.`);
  }
  priorities.push(
    priorities.length === 1
      ? `Priority 2 — Pick the single best channel and show up consistently${facts.channels.length ? ` (${facts.channels.join(' and ')} since that's where you already operate)` : ''} before adding a second one.`
      : `Priority ${priorities.length + 1} — Concentrate activity on one primary channel rather than spreading across many.`
  );
  priorities.push(`Priority ${priorities.length + 1} — Attach a number to everything: every post, ad and email points to one measurable action you can count in Marketing Analytics.`);

  const budgetBlock = budget
    ? `BUDGET
Working with ${budget.toLocaleString()}${facts.budget ? (budgetMatch0IsMonthly(facts, brief) ? ' per month' : '') : ' per month'}:
• Content & organic social — 40% (${Math.round(budget * 0.4).toLocaleString()})
• Focused paid promotion of the best-performing content — 35% (${Math.round(budget * 0.35).toLocaleString()})
• Capture & nurture (landing page, email tooling) — 15% (${Math.round(budget * 0.15).toLocaleString()})
• Untouched reserve for testing — 10% (${Math.round(budget * 0.1).toLocaleString()})
Reallocate monthly toward whichever line produces the cheapest genuine enquiry.`
    : 'BUDGET
No budget figure was provided, so the plan above is deliberately organic-first. Tell me the monthly amount you are willing to commit and I will rebuild the allocation around it.';

  const leadTarget = budget ? Math.max(5, Math.round(budget / 60)) : 10;
  const measurementBlock = `MEASUREMENT
Review weekly in Marketing Analytics; judge the plan on these, not on vibes:
• ${goalText ? `The stated objective — ${goalText.split(';')[0]} — tracked monthly against today's baseline.` : `Qualified enquiries per month: ${leadTarget}+ by day 90.`}
• Cost per enquiry (if spending): trending down month over month.
• Publishing consistency: 90% of scheduled items actually shipped.
• One honest number pinned to the 90-day target above — no vanity metrics.`;

  const marketLine = facts.market.length
    ? ` The market context you described — ${facts.market[0]} — makes the focus and sequencing above deliberately conservative: earn from one motion before funding a second.`
    : '';

  return qualityPass(`READ OF THE BRIEF
You told me: “${brief.length > 320 ? brief.slice(0, 320).trim() + '…' : brief.trim()}”
My read: ${company} wants ${goalText ? 'to ' + goalText.split(';')[0] : 'to grow'}, serving ${audience}, with ${products}.${facts.timeline ? ` The deadline in play is ${facts.timeline}.` : ''}${facts.locations.length ? ` Operating in ${facts.locations.join(' and ')}.` : ''}${marketLine}

POSITIONING
${company} wins by standing for one specific promise to ${audience}${value ? ` — your stated edge of “${value}” is the anchor` : ''}. ${industry ? `Within ${industry}, the practical differentiator is proof, not adjectives: ` : 'The practical differentiator is proof, not adjectives: '}specific results, real processes, named customers. Everything below repeats that promise in the same words.

${priorities.join('\n\n')}

90-DAY PLAN
Weeks 1–2 · Message clarity: one headline, one offer, one audience — rewrite the site hero and bios around ${audience}.
Weeks 3–6 · Execute: publish 3–4 pieces weekly on ${facts.channels.length ? facts.channels.join(' and ') : 'your single best channel'}, capture every enquiry with a source tag.
Weeks 7–12 · Optimise: cut the weakest activity, double the strongest, and rebuild next quarter's plan from the numbers.

${budgetBlock}

${measurementBlock}

ASSUMPTIONS
${assumptions.map((a) => `• ${a}`).join('\n')}

NEXT STEP
Pressure-test this: tell me which priority feels wrong, or give me the missing facts (budget, customer type, timeline) and I'll rebuild the plan around them.${isFollowUp ? '\nWe are mid-conversation — say “expand priority 1” or “make this a 30-day plan” and I'll go deeper on exactly that.' : ''}`);
}

function budgetMatch0IsMonthly(facts: BriefFacts, brief: string): boolean {
  return /month/i.test(brief) || facts.timeline === null;
}

// Model-backed generation: the complete brief, business profile and
// conversation history are passed to the PANDA strategy model every time.
export async function strategyAI(
  bp: BusinessProfile | null,
  brief: string,
  thread: StrategyTurn[]
): Promise<{ strategy: string; source: 'model' | 'local' }> {
  try {
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/strategy-ai`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        brief,
        history: thread.slice(-8),
        profile: bp
          ? {
              company_name: bp.company_name,
              industry: bp.industry,
              products_services: bp.products_services,
              target_audience: bp.target_audience,
              brand_voice: bp.brand_voice,
              unique_value: bp.unique_value,
              website: bp.website,
              monthly_budget: bp.monthly_budget,
            }
          : {},
      }),
    });
    if (!res.ok) throw new Error(`model unavailable (${res.status})`);
    const data = await res.json();
    if (!data?.strategy || typeof data.strategy !== 'string' || data.strategy.trim().length < 40) {
      throw new Error('invalid model response');
    }
    return { strategy: data.strategy.trim(), source: 'model' };
  } catch {
    return { strategy: composeStrategy(bp, brief, extractFacts(brief), thread.length > 0), source: 'local' };
  }
}

export function strategyReply(
  bp: BusinessProfile | null,
  instruction: string,
  thread: StrategyTurn[]
): string {
  return composeStrategy(bp, instruction, extractFacts(instruction), thread.length > 0);
}



export function assistantReply(
  bp: BusinessProfile | null,
  question: string
): string {
  const company = bp?.company_name || 'your business';
  const q = question.toLowerCase();
  const has = (...words: string[]) => words.some((w) => q.includes(w));

  if (has('budget', 'spend', 'cost')) {
    const budget = bp?.monthly_budget || 2000;
    return `Based on your profile, here's a sensible monthly budget split for ${company} (working with $${budget.toLocaleString()}/month):\n\n• 40% Social media (organic + paid) — $${Math.round(budget * 0.4).toLocaleString()}\n• 30% Search / Google Ads — $${Math.round(budget * 0.3).toLocaleString()}\n• 15% Email marketing — $${Math.round(budget * 0.15).toLocaleString()}\n• 15% Content & partnerships — $${Math.round(budget * 0.15).toLocaleString()}\n\nReview performance after 30 days: shift budget toward whichever channel delivers the lowest cost per lead. Keep roughly 10% unallocated for experiments.`;
  }
  if (has('lead', 'customer acquisition', 'prospect')) {
    return `To generate more leads for ${company}, run this simple three-step system:\n\n1. ATTRACT — Publish 3-4 social posts per week addressing the single biggest problem ${bp?.target_audience || 'your audience'} faces. Promote your best performer with a small paid budget.\n2. CAPTURE — Offer something genuinely useful (a checklist, quote, free consultation) in exchange for an email. Track every lead in your Leads workspace with a source label.\n3. NURTURE — Send a 3-email welcome sequence: introduce ${company}, share proof (results, testimonials), then make a clear offer.\n\nMeasure cost per lead weekly. Kill what doesn't work within 2 weeks; double what does.`;
  }
  if (has('post', 'social', 'content idea', 'instagram', 'facebook', 'linkedin')) {
    return `Here are 5 ready-to-use post ideas for ${company}:\n\n1. Behind the scenes — show how ${bp?.products_services || 'your product'} gets made or delivered. Builds trust.\n2. Customer story — one specific result a customer got, told in their words.\n3. Myth vs reality — pick a common misconception in ${bp?.industry || 'your industry'} and correct it.\n4. Quick tip — a 30-second answer to the question customers ask you most.\n5. Offer with a deadline — a clear, time-limited reason to act now.\n\nHead to Content Creator and I can draft any of these for you in your brand voice.`;
  }
  if (has('strategy', 'plan', 'growth', 'positioning')) {
    return `A focused 90-day growth plan for ${company}:\n\nWEEKS 1-2: Sharpen positioning. One sentence: "${company} helps ${bp?.target_audience || '[your audience]'} achieve [outcome] through ${bp?.unique_value || '[your unique value]'}." Everything else flows from this.\n\nWEEKS 3-6: Consistency. Publish on a fixed schedule, launch one small paid test, capture every lead with a source tag.\n\nWEEKS 7-12: Optimise. Review Marketing Analytics weekly. Cut the worst-performing channel, increase spend on the best, and produce more of the content your audience engaged with.\n\nWant this as a saved strategy document? Use "Generate strategy" on the Marketing Strategy page.`;
  }
  if (has('competitor', 'rival', 'market')) {
    return `Here's a quick competitor analysis framework for ${bp?.industry || 'your market'}:\n\n1. List your 3-5 closest competitors.\n2. For each, note: their main promise, pricing approach, best-performing content, and weakest point.\n3. Read their customer reviews — recurring complaints reveal exactly where you can win.\n4. Position ${company} against the gap, not against the crowd. Don't echo their message; answer their customers' frustrations.\n\nSave your findings in a strategy document so your whole team works from the same picture.`;
  }
  if (has('email', 'newsletter')) {
    return `For ${company}, the highest-performing email is a simple 3-part welcome sequence:\n\nEmail 1 (immediately): Warm welcome + deliver the promised freebie or intro. One link only.\nEmail 2 (day 3): Proof — a customer result or testimonial tied to ${bp?.unique_value || 'your value'}.\nEmail 3 (day 6): A clear, time-limited offer with one call to action.\n\nKeep subject lines under 45 characters and write like you're emailing one person, not a list.`;
  }
  if (has('roi', 'return', 'measure', 'metric', 'kpi', 'performance')) {
    return `The four numbers that matter most for ${company}:\n\n1. Cost per lead — total spend ÷ leads generated.\n2. Conversion rate — leads ÷ website visitors or enquiries.\n3. Customer lifetime value — average revenue per customer over 12+ months.\n4. Return on marketing investment — revenue attributed to marketing ÷ spend.\n\nCheck Marketing Analytics weekly. If ROAS is above 3x, scale carefully; below 1.5x, fix the offer or the audience before spending more.`;
  }
  if (has('hello', 'hi', 'hey', 'help', 'what can you')) {
    return `Hello! I'm PANDA, your AI marketing assistant${bp ? ` for ${bp.company_name}` : ''}. I can help you:\n\n• Plan marketing strategy and budgets\n• Draft social posts, emails, ads and website copy\n• Recommend how to generate and nurture leads\n• Interpret your campaign performance\n\nI know your business profile${bp?.industry ? ` (${bp.industry})` : ''}, so just ask in plain language — for example "How should I split my budget?" or "Give me post ideas for next week".`;
  }

  return `Here's my practical take on "${question}" for ${company}:\n\n1. Start from the customer. The fastest path is usually clearer messaging to ${bp?.target_audience || 'your core audience'} — one specific promise, repeated everywhere.\n2. Pick ONE channel to win this month rather than spreading thin. Consistency beats presence.\n3. Attach an offer and a measurable action to everything you publish, then track results in Marketing Analytics.\n\nIf you'd like, I can turn this into campaign content — just open Content Creator, or ask me about budgets, leads, social posts, email, competitors or measuring ROI.`;
}
