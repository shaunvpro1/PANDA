import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';
import type { BusinessProfile } from './types';

export function useProfile() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const refetch = useCallback(async () => {
    const { data } = await supabase.from('business_profile').select('*').eq('id', 1).maybeSingle();
    setProfile(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const save = useCallback(
    async (patch: Partial<BusinessProfile>) => {
      const { data, error } = await supabase
        .from('business_profile')
        .update({ ...patch, updated_at: new Date().toISOString() })
        .eq('id', 1)
        .select()
        .maybeSingle();
      if (!error && data) setProfile(data);
      return error;
    },
    []
  );

  return { profile, loading, save };
}
