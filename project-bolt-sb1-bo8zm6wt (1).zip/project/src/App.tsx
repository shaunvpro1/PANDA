import { useState } from 'react';
import { AppShell } from '@/components/AppShell';
import type { PageKey } from '@/components/nav';
import { Dashboard } from '@/pages/Dashboard';
import { StrategyPage } from '@/pages/Strategy';
import { CampaignStudio } from '@/pages/CampaignStudio';
import { ContentCreator } from '@/pages/ContentCreator';
import { SocialMedia } from '@/pages/SocialMedia';
import { Leads } from '@/pages/Leads';
import { Analytics } from '@/pages/Analytics';
import { Assistant } from '@/pages/Assistant';
import { Settings } from '@/pages/Settings';

function App() {
  const [page, setPage] = useState<PageKey>('dashboard');

  return (
    <AppShell page={page} onNavigate={setPage}>
      {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
      {page === 'strategy' && <StrategyPage />}
      {page === 'campaigns' && <CampaignStudio />}
      {page === 'content' && <ContentCreator />}
      {page === 'social' && <SocialMedia />}
      {page === 'leads' && <Leads />}
      {page === 'analytics' && <Analytics />}
      {page === 'assistant' && <Assistant />}
      {page === 'settings' && <Settings />}
    </AppShell>
  );
}

export default App;
