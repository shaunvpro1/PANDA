/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#060b18',
          900: '#0a1224',
          850: '#0e1830',
          800: '#13203c',
          700: '#1c2d4f',
          600: '#27406b',
          500: '#3a5788',
        },
        'electric': {
          300: '#7db4ff',
          400: '#4d94ff',
          500: '#1a73ff',
          600: '#0b5ced',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        display: ['Sora', 'Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 24px rgba(26, 115, 255, 0.35)',
      },
    },
  },
  plugins: [],
};
