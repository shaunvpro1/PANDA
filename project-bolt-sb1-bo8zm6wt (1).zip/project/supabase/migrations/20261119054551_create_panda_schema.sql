/*
# PANDA initial schema (single-tenant, no auth)

1. New Tables
- `business_profile` (single row): company name, industry, products/services,
  target audience, brand voice, website, unique value proposition, monthly budget.
  Drives all AI personalisation across the platform.
- `strategies`: marketing strategy documents - positioning, audience segments,
  competitor notes, objectives, budget allocation, recommended channels.
- `campaigns`: campaign records with objective, audience, channels, budget,
  start/end dates, status (draft, active, paused, completed).
- `content_items`: generated marketing content - social posts, emails, ads,
  website copy, product descriptions. Linked optionally to a campaign.
- `social_posts`: scheduled/published social posts with platform, scheduled time,
  status (draft, scheduled, published), and engagement metrics.
- `leads`: captured leads with name, email, company, source, status
  (new, contacted, qualified, won, lost), value, and notes.
- `assistant_messages`: AI Marketing Assistant chat history with role
  (user / assistant) and message body.
- `metrics`: simple daily metric snapshots (spend, impressions, clicks,
  conversions, revenue) used by the analytics dashboards.

2. Security
- Enable RLS on every table.
- Grant anon + authenticated the CRUD verbs used by the app (no-auth
  single-tenant app: policies TO anon, authenticated USING (true)).
- Single-row protection on business_profile enforced by app logic.

3. Notes
- No auth in this version; data is intentionally shared across the workspace.
- Indexes on foreign keys and frequently filtered columns (status, platform).
*/

CREATE TABLE IF NOT EXISTS business_profile (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  company_name text NOT NULL DEFAULT 'My Business',
  industry text NOT NULL DEFAULT '',
  products_services text NOT NULL DEFAULT '',
  target_audience text NOT NULL DEFAULT '',
  brand_voice text NOT NULL DEFAULT 'Professional',
  website text NOT NULL DEFAULT '',
  unique_value text NOT NULL DEFAULT '',
  monthly_budget numeric NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO business_profile (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS strategies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  positioning text NOT NULL DEFAULT '',
  audience text NOT NULL DEFAULT '',
  competitors text NOT NULL DEFAULT '',
  objectives text NOT NULL DEFAULT '',
  budget_notes text NOT NULL DEFAULT '',
  channels text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  objective text NOT NULL DEFAULT 'awareness',
  audience text NOT NULL DEFAULT '',
  channels text[] NOT NULL DEFAULT '{}',
  budget numeric NOT NULL DEFAULT 0,
  start_date date,
  end_date date,
  status text NOT NULL DEFAULT 'draft',
  description text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS content_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content_type text NOT NULL DEFAULT 'social_post',
  platform text NOT NULL DEFAULT '',
  body text NOT NULL,
  campaign_id uuid REFERENCES campaigns(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL,
  content text NOT NULL,
  scheduled_at timestamptz,
  status text NOT NULL DEFAULT 'draft',
  impressions integer NOT NULL DEFAULT 0,
  likes integer NOT NULL DEFAULT 0,
  comments integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  campaign_id uuid REFERENCES campaigns(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL DEFAULT '',
  company text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT 'manual',
  status text NOT NULL DEFAULT 'new',
  value numeric NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assistant_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day date NOT NULL UNIQUE,
  spend numeric NOT NULL DEFAULT 0,
  impressions integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  revenue numeric NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);
CREATE INDEX IF NOT EXISTS idx_content_type ON content_items(content_type);
CREATE INDEX IF NOT EXISTS idx_social_platform ON social_posts(platform);
CREATE INDEX IF NOT EXISTS idx_social_status ON social_posts(status);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);

ALTER TABLE business_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE strategies ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE metrics ENABLE ROW LEVEL SECURITY;

GRANT SELECT, UPDATE ON business_profile TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON strategies TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON campaigns TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON content_items TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON social_posts TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON leads TO anon, authenticated;
GRANT SELECT, INSERT, DELETE ON assistant_messages TO anon, authenticated;
GRANT SELECT, INSERT ON metrics TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_business_profile" ON business_profile;
CREATE POLICY "anon_select_business_profile" ON business_profile FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_update_business_profile" ON business_profile;
CREATE POLICY "anon_update_business_profile" ON business_profile FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_select_strategies" ON strategies;
CREATE POLICY "anon_select_strategies" ON strategies FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_strategies" ON strategies;
CREATE POLICY "anon_insert_strategies" ON strategies FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_strategies" ON strategies;
CREATE POLICY "anon_update_strategies" ON strategies FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_strategies" ON strategies;
CREATE POLICY "anon_delete_strategies" ON strategies FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_campaigns" ON campaigns;
CREATE POLICY "anon_select_campaigns" ON campaigns FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_campaigns" ON campaigns;
CREATE POLICY "anon_insert_campaigns" ON campaigns FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_campaigns" ON campaigns;
CREATE POLICY "anon_update_campaigns" ON campaigns FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_campaigns" ON campaigns;
CREATE POLICY "anon_delete_campaigns" ON campaigns FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_content_items" ON content_items;
CREATE POLICY "anon_select_content_items" ON content_items FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_content_items" ON content_items;
CREATE POLICY "anon_insert_content_items" ON content_items FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_content_items" ON content_items;
CREATE POLICY "anon_update_content_items" ON content_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_content_items" ON content_items;
CREATE POLICY "anon_delete_content_items" ON content_items FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_social_posts" ON social_posts;
CREATE POLICY "anon_select_social_posts" ON social_posts FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_social_posts" ON social_posts;
CREATE POLICY "anon_insert_social_posts" ON social_posts FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_social_posts" ON social_posts;
CREATE POLICY "anon_update_social_posts" ON social_posts FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_social_posts" ON social_posts;
CREATE POLICY "anon_delete_social_posts" ON social_posts FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_leads" ON leads;
CREATE POLICY "anon_select_leads" ON leads FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_leads" ON leads;
CREATE POLICY "anon_update_leads" ON leads FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_leads" ON leads;
CREATE POLICY "anon_delete_leads" ON leads FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_assistant_messages" ON assistant_messages;
CREATE POLICY "anon_select_assistant_messages" ON assistant_messages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_assistant_messages" ON assistant_messages;
CREATE POLICY "anon_insert_assistant_messages" ON assistant_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_assistant_messages" ON assistant_messages;
CREATE POLICY "anon_delete_assistant_messages" ON assistant_messages FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_metrics" ON metrics;
CREATE POLICY "anon_select_metrics" ON metrics FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_metrics" ON metrics;
CREATE POLICY "anon_insert_metrics" ON metrics FOR INSERT TO anon, authenticated WITH CHECK (true);
