/*
# Create strategy_messages table (single-tenant, no auth)

1. New Tables
- `strategy_messages`: persistent AI strategy workspace conversation history.
  - `id` (uuid, primary key)
  - `role` (text: 'user' | 'assistant')
  - `body` (text: the prompt or the structured strategy response)
  - `created_at` (timestamp)

2. Security
- Enable RLS on `strategy_messages`.
- Grant SELECT, INSERT, DELETE to anon + authenticated (no-auth single-tenant
  app: policies TO anon, authenticated USING (true) — data intentionally
  shared across the workspace).

3. Notes
- Keeps the Strategy workspace conversation separate from the general AI
  Assistant chat (assistant_messages) so both threads persist independently.
*/

CREATE TABLE IF NOT EXISTS strategy_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE strategy_messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON strategy_messages TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_strategy_messages" ON strategy_messages;
CREATE POLICY "anon_select_strategy_messages" ON strategy_messages FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_strategy_messages" ON strategy_messages;
CREATE POLICY "anon_insert_strategy_messages" ON strategy_messages FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_strategy_messages" ON strategy_messages;
CREATE POLICY "anon_delete_strategy_messages" ON strategy_messages FOR DELETE
TO anon, authenticated USING (true);
