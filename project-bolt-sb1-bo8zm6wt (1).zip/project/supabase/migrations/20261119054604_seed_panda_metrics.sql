/*
# Seed PANDA demo metrics (90 days of daily marketing snapshots)

1. Modified Tables
- `metrics`: inserts 90 daily rows ending today with realistic spend,
  impressions, clicks, conversions and revenue data generated deterministically
  via generate_series + hash-based pseudo-randomness. ON CONFLICT (day) DO
  NOTHING makes it safe to re-run.

2. Security
- No changes; table RLS and grants already exist.

3. Notes
- Purely illustrative performance data so the Analytics and Dashboard views are
  functional on first launch.
*/

INSERT INTO metrics (day, spend, impressions, clicks, conversions, revenue)
SELECT
  d::date,
  round((180 + (abs(hashtext(d::text)) % 120))::numeric, 2),
  4200 + (abs(hashtext('imp' || d::text)) % 3800),
  180 + (abs(hashtext('clk' || d::text)) % 320),
  6 + (abs(hashtext('cnv' || d::text)) % 24),
  round((450 + (abs(hashtext('rev' || d::text)) % 2100))::numeric, 2)
FROM generate_series(
  (current_date - interval '89 days')::date,
  current_date,
  interval '1 day'
) AS d
ON CONFLICT (day) DO NOTHING;
