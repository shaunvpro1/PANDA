// PANDA strategy generation — passes the complete user brief, business profile
// and conversation context to the configured AI model and returns a structured
// strategist-grade response. The API key is read from secrets, never exposed.

import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface StrategyTurn {
  role: "user" | "assistant";
  body: string;
}

interface StrategyRequest {
  brief: string;
  history?: StrategyTurn[];
  profile?: {
    company_name?: string;
    industry?: string;
    products_services?: string;
    target_audience?: string;
    brand_voice?: string;
    unique_value?: string;
    website?: string;
    monthly_budget?: number;
  };
}

const SYSTEM_PROMPT = `You are PANDA, a commercially experienced marketing director with 20+ years growing real businesses.

You produce strategies that are specific, practical and commercially relevant. You are NOT a generic marketing text generator.

Rules:
1. Ground every recommendation in the actual brief: use the business, products, target customers, budget, objectives and market circumstances the user supplied. Quote and build on their specifics.
2. Where information is missing, state the assumption explicitly in an ASSUMPTIONS section ("Assumed X — correct me if wrong"). Never invent facts, customers, numbers or claims as if they were real.
3. Give recommendations a real strategist would give: named channels, specific actions, realistic numbers, priorities in order, and trade-offs. No filler like "leverage synergies" or "utilise omnichannel touchpoints".
4. Structure the response with clear ALL-CAPS section headings and short paragraphs or bullets:
   READ OF THE BRIEF · POSITIONING · PRIORITY AUDIENCE · ACTION PLAN (with priorities 1,2,3) · 90-DAY PLAN (weekly milestones) · BUDGET (only if budget info exists) · MEASUREMENT (measurable objectives with target numbers) · ASSUMPTIONS · NEXT STEP.
   Omit sections that do not apply. For follow-up messages, respond to exactly what was asked — do not regenerate the whole plan.
5. Be concise and skimmable. No repetition between sections. Professional grammar throughout.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { brief, history = [], profile = {} }: StrategyRequest = await req.json();

    if (!brief || typeof brief !== "string" || brief.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "A strategy brief is required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const apiKey = Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "no_model", detail: "No AI model key is configured for this project yet." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const contextLines: string[] = [];
    if (profile.company_name) contextLines.push(`Company: ${profile.company_name}`);
    if (profile.industry) contextLines.push(`Industry: ${profile.industry}`);
    if (profile.products_services) contextLines.push(`Products/services: ${profile.products_services}`);
    if (profile.target_audience) contextLines.push(`Target audience: ${profile.target_audience}`);
    if (profile.brand_voice) contextLines.push(`Brand voice: ${profile.brand_voice}`);
    if (profile.unique_value) contextLines.push(`Unique value: ${profile.unique_value}`);
    if (profile.website) contextLines.push(`Website: ${profile.website}`);
    if (profile.monthly_budget) contextLines.push(`Monthly marketing budget: $${profile.monthly_budget}`);

    const contextBlock = contextLines.length
      ? `BUSINESS PROFILE ON FILE\n${contextLines.join("\n")}\n\n`
      : "";

    const historyBlock = history.length
      ? `CONVERSATION SO FAR\n${history
          .slice(-8)
          .map((t) => `${t.role === "user" ? "Client" : "PANDA"}: ${t.body.slice(0, 600)}`)
          .join("\n---\n")}\n\n`
      : "";

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: `${contextBlock}${historyBlock}CURRENT BRIEF\n${brief.trim()}`,
      },
    ];

    const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages,
        temperature: 0.7,
        max_tokens: 1600,
      }),
    });

    if (!aiRes.ok) {
      const detail = await aiRes.text().catch(() => "");
      return new Response(
        JSON.stringify({ error: "model_error", detail: detail.slice(0, 300) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const data = await aiRes.json();
    const strategy = data?.choices?.[0]?.message?.content;
    if (!strategy || typeof strategy !== "string") {
      return new Response(
        JSON.stringify({ error: "empty_model_response" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(JSON.stringify({ strategy }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "server_error", detail: err instanceof Error ? err.message : "unknown" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
